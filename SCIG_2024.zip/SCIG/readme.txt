python 3.7.4

Required packages: sklearn, scipy.

1. Users can run the run.bat to reproduce the experiments in the paper. (For single - cell sequencing data, users can run the run.bat in the 'single_cell_sequencing_data' directory.)


2. Users are able to run the method on their own data. There is a simple example in the file AnExampleForUsers.py. All users need to do is load their data and call the function AnExampleForUsers. 


"""
Load your data. You can only load X, in numpy.array format.
"""
[X,Y] = LoadData('Iris') 


AnExampleForUsers(X, minK=2,maxK=15)  # Find the best K and the clustering method.
"""
Find the best clustering method  and the k within the range from 2 to 15.
You can add your own clustering method in this function. 
If not added, methods such as KMeans and GaussianMixture are used by default.
"""
 

