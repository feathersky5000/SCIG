# -*- coding: utf-8 -*-
"""
Created on Tue May 25 16:19:39 2021

@author: Xiaojun Ding
"""


from OPCluster import *

from OPClusterTest import *

#------------------------ An example that users can use their data and clustering algorithm-------------





# Users can add or remove their clustering methods or parameters
# The clustering methods should provide a function fit(X,k), where X is the input, k is the number of clusters. The function should return a clustering result just like the following:




#--------------------------------------------------
"""
An example of clustering method by user
"""


def fit_by_user(X, k):
    """
    This function performs clustering on the input data X using the KMeans algorithm with custom settings.

    :param X: numpy.ndarray or a similar data structure, representing the data to be clustered.
              Each row of X is an observation, and each column is a feature.
    :param k: int, the number of clusters to form.

    :return: numpy.ndarray of shape (n,), where n is the number of observations in X.
             This array contains the cluster labels for each observation in X.
    """

    kmeans = KMeans(n_clusters=k, init='random', n_init=10).fit(X)
    return kmeans.labels_




#--------------------------------------------------
    


def AnExampleForUsers(X,minK=2,maxK=15,FigureOff=False,noiseRatio=0.1,noisingMethod='gaussian'):
    
       
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
   
    #--------------For method type = 1, this method is unable to determine k on its own-----------------  
        
    op.AddClusteringMethod('clustering (user)',fit_by_user)        # the clustering method written by user  
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)

    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
    
    
    
    #--------------For method type = 2, they are able to find k by themselves-----------------
    op.methods2={}
    
    op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    
    
    op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
   
           
    #---------------------------------------------------------------------------------
    
    op.OpCluster(X,Y=None,minK=minK,maxK=maxK,savePath='result\\',noiseRatio=noiseRatio,noisingMethod=noisingMethod)
    


#-----------------------------------------------
    
    

"""
Load your data. You can only load X, in numpy.array format.
"""
[X,Y] = LoadData('Iris') 


AnExampleForUsers(X, minK=2,maxK=15)  # Find the best K and clustering method.
"""
Find the best k within the range from 2 to 15 and the clustering method.
You can add your own clustering method in this function. 
If not added, methods such as KMeans and GaussianMixture are used by default.
"""
 

