# -*- coding: utf-8 -*-
"""
Created on Mon Jun 10 15:08:58 2019

@author:  Xiaojun Ding


 

"""



import warnings

warnings.filterwarnings('ignore')



import numpy as np
import pandas as pd

from sklearn import metrics



#from Bio.Cluster import kcluster          # pip install biopython

from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import Birch 
from sklearn.cluster import SpectralClustering

from sklearn.mixture import GaussianMixture


from sklearn.cluster import KMeans

from sklearn import datasets


import matplotlib.pyplot as plt

from sklearn.datasets import make_blobs

from sklearn.cluster import MeanShift


from sklearn.cluster import AffinityPropagation

import scipy.io as scio
    
from sklearn import cluster


from scipy.io import arff



from sklearn import preprocessing


# Imports
from sklearn.datasets import fetch_olivetti_faces

import mnist


import io

import os 

import random
import sys


import struct

from collections import Counter


from scipy.spatial.distance import pdist
from scipy.spatial.distance import squareform



import pandas as pd

from sklearn.preprocessing import LabelEncoder



#-----------------------------------------------------------------------------------
    

# method: specifies how the center of a cluster is found: - method == 'a': arithmetic mean - method == 'm': median

# dist: specifies the distance function to be used: - dist == 'e': Euclidean distance - dist == 'b': City Block distance - 
# dist == 'c': Pearson correlation - dist == 'a': absolute value of the correlation - dist == 'u': uncentered correlation - 
# dist == 'x': absolute uncentered correlation - dist == 's': Spearman's rank correlation - dist == 'k': Kendall's tau

#class kclusterModel:    
#    
#    def __init__(self, method='a', dist='e'):
#        
#        self.method=method
#        self.dist=dist        
#        
#    def fit(self,X,k):
#        
#        clusterid, error, nfound = kcluster(X,nclusters=k,method=self.method, dist=self.dist)   # If you do not install the 'biopython' package, you can replace the 'kcluster' method with 'KMeans' 
#        return clusterid
#    
    
    
#----------------------------------------------------------

class KMeansModel:
#    def __init__(self):
        
        
    def fit(self,X,k):
        
        # The clustering reuslts are related to initial values.
        # If useing the 'k-means++’ parameter, for some datasets, the initial values are always the same and then we may always get the same local optima
        # If k-means can get the global optima, it will not affect our methods. But, if it always get the same local optima, our method will lose efficacy. So at here, we use init='random' , and get the best result for 10 times (n_init=10)
        #‘k-means++’ : selects initial cluster centers for k-mean clustering in a smart way to speed up convergence. 
        
        kmeans = KMeans(n_clusters=k,init='random',n_init=10).fit(X)  
       
        
        return kmeans.labels_
    
    

#--------------------------------------------------------------------------

#    covariance_type : {‘full’ (default), ‘tied’, ‘diag’, ‘spherical’}
#    String describing the type of covariance parameters to use. Must be one of:
#    
#    ‘full’
#    each component has its own general covariance matrix
#    
#    ‘tied’
#    all components share the same general covariance matrix
#    
#    ‘diag’
#    each component has its own diagonal covariance matrix
#    
#    ‘spherical’
#    each component has its own single variance



class GaussianMixtureModel:    
    
    def __init__(self,covariance_type='full'):
               
        self.covariance_type=covariance_type       
        
    def fit(self,X,k):
        
        nF=X.shape[1]
        
        if nF>2000:         # out of menory
            gmm = GaussianMixture(n_components=k, covariance_type='spherical').fit(X)
        else:
            gmm = GaussianMixture(n_components=k, covariance_type=self.covariance_type).fit(X)
            
        return gmm.predict(X)




   
    
    
#-----------------------------------------------------------------------------------
    
# affinity : string or callable, default: “euclidean”
# Metric used to compute the linkage. Can be “euclidean”, “l1”, “l2”, “manhattan”, “cosine”, or “precomputed”. If linkage is “ward”, only “euclidean” is accepted. If “precomputed”, a distance matrix (instead of a similarity matrix) is needed as input for the fit method.

# linkage : {“ward”, “complete”, “average”, “single”}, optional (default=”ward”)
# Which linkage criterion to use. The linkage criterion determines which distance to use between sets of observation. The algorithm will merge the pairs of cluster that minimize this criterion.

# ward minimizes the variance of the clusters being merged.
# average uses the average of the distances of each observation of the two sets.
# complete or maximum linkage uses the maximum distances between all observations of the two sets.
# single uses the minimum of the distances between all observations of the two sets.
        
class AgglomerativClusteringModel:    

    def __init__(self, affinity='euclidean', linkage='ward'):
        
        self.affinity=affinity
        self.linkage=linkage        
        
    def fit(self,X,k):
        
        return AgglomerativeClustering(n_clusters=k, affinity=self.affinity, linkage=self.linkage).fit_predict(X) 



#-------------------------------------------
    

# threshold : float, default 0.5
# The radius of the subcluster obtained by merging a new sample and the closest subcluster should be lesser than the threshold. Otherwise a new subcluster is started. Setting this value to be very low promotes splitting and vice-versa.
#
# branching_factor : int, default 50
# Maximum number of CF subclusters in each node. If a new samples enters such that the number of subclusters exceed the branching_factor then that node is split into two nodes with the subclusters redistributed in each. The parent subcluster of that node is removed and two new subclusters are added as parents of the 2 split nodes.

class BirchModel:    
    
    def __init__(self, branching_factor=50,threshold=0.5):
        
        self.branching_factor=branching_factor
        self.threshold=threshold        
        
    def fit(self,X,k):
        
        return Birch(branching_factor=self.branching_factor, n_clusters=k, threshold=self.threshold).fit_predict(X) 
    
    
    
    

#----------------clustering algorithm (type=2)----------------------
        
    
    

class MeanShiftModel:    
    
    def __init__(self, branching_factor=50,threshold=0.5):
        
        self.branching_factor=branching_factor
        self.threshold=threshold        
        
    def fit(self,X):
        
        clustering = MeanShift().fit(X)
        
        return clustering.labels_






#-------------------------------------------
    

class SpectraClusteringModel:    
    
    def __init__(self, affinity='rbf',gamma=1):
        
        self.affinity=affinity
        self.gamma=gamma        
        
    def fit(self,X,k):
        
        return SpectralClustering(n_clusters=k, affinity=self.affinity, gamma=self.gamma).fit_predict(X) 
        
        

#-------------------------------------------
    

class AffinityPropagationModel:    
    
    def __init__(self,affinity='euclidean', damping=0.5,  preference=None):
        
        self.affinity=affinity
        self.damping=damping
        self.preference=preference    
        
    def fit(self,X):
        
        model = AffinityPropagation(affinity=self.affinity, damping=self.damping, preference=self.preference)
        
        model.fit(X)
        
        return model.labels_        
        

#------------------------------------------------------------------
    






class NoisingByNeighbours:
    
    # def __init__(self):       
             
     

    def AddNoiseToX(self,X,ratio=2):
        
        
        noisedX=X.copy()
        
        nX=X.shape[0]          
        nF=X.shape[1]
        
        
        distA=pdist(X,metric='euclidean')
        # 将distA数组变成一个矩阵
        distX = squareform(distA)


        c=ratio/np.sqrt(nF)
        
        for i in range(nX):
            distX[i,i]=100000000
            
            minD= np.min(distX[i,:])
            
            noise=np.random.randn(nF)*minD*c
            
            noisedX[i,:]+=noise
        
        return noisedX



#---------------------------------------------------------------


class NoisingByCombingGaussianAndNeighbours:
    
    # def __init__(self):       
             
     

    def AddNoise0(self,X,ratio=0.1):
   
        nX=X.shape[0]
        nF=X.shape[1]
        
        noisedX=np.zeros((nX,nF))
        
        for i in range(X.shape[1]):
    #            _mean = np.mean(X[:,i])
            _var = np.var(X[:,i])
            _stdVar=np.sqrt(_var)
            
            #print(_mean,_var,_stdVar)
            
            
            noise=np.random.randn((nX))*_stdVar*ratio
            
            noisedX[:,i]=X[:,i]+noise
        
        return noisedX
    
        
    def AddNoiseToX(self,X,ratio1=0.05,ratio2=1):

        nX=X.shape[0]
        nF=X.shape[1]
        
        if nF>2000:         # out of menory
            noisedX= self.AddNoise0(X,ratio1) 
        else:        
         
            covX=np.cov(X.T)               
            noise=np.random.multivariate_normal(np.zeros(nF,),covX,nX)*ratio1                 
            noisedX=X+noise
        
        
        noising= NoisingByNeighbours()
       
        return noising.AddNoiseToX(noisedX,ratio2)
        
            
       
            




#---------------------------------------------------------------



class NoisingForCategory:
    
    # def __init__(self):       
             
     

    def grades_keys(self,X,i):
        
        cc = Counter(X[:,i])
        keys=list(cc)
        
        grades=np.zeros(len(keys)+1)
        
        grades[0]=0
        
        for k in range(len(keys)):
            
            grades[k+1]=grades[k]+cc[keys[k]]
            
        return [grades,keys]
      
    
    def RandV(self,grades,keys,value):
        
        for i in range(100):
            
            t=np.random.randint(0,grades[len(grades)-1])   
            
            for k in range(len(grades)):
                if t<grades[k]:
                    if (value!=keys[k-1]):
                        return keys[k-1]
                    break
            
        return value
            
    
    def Noising_Col_i(self,X,i,ratio):
        
        nX=X.shape[0]
    
        randX=np.random.rand(nX)
        
        idx=np.where(randX<ratio)        
        
        [grades,keys]=self.grades_keys(X,i)      
        
        for iRow in idx[0]:          
            X[iRow,i]=self.RandV(grades,keys,X[iRow,i])
         
        
     
           
            
    def AddNoiseToX(self,X,ratio=0.1):
        
        noisedX=X.copy()      
        
        for i in range(X.shape[1]):
            self.Noising_Col_i(noisedX,i,ratio)
      
        
        return noisedX
           



#------------------------------------------------------------------------------------------









class OPClustering:
    
    
    def __init__(self):       
       
        
        self.methods={}       
        
        self.methods2={}
        
        self.FigureOff=False
        
        
        self.ratio1=0.05
        self.ratio2=1
      
        
     # methodType==1 means that we can assign the K for the method, otherwise, the method can compute the K itself.
    
    def AddClusteringMethod(self,name,method,methodType=1):
        
        if methodType==1:
            self.methods[name]=method
        else:
            self.methods2[name]=method
        
        
    
                        

    #--------------------------------------------------------------------
        
        
        
        
    def PlotClusters(self,X,Y,bSubPlot=False):
        
        if self.FigureOff:
            return        
      
#        plt.rcParams['figure.figsize'] = (4.0, 4.0) # 设置figure_size尺寸    
        
        colors = ['r','g', 'b','c','m',  'y']  
        
        markers=['.','+','*','x','d']
        
        labels=pd.value_counts(Y)   
        
        for i in range(len(labels)):
            
            clusterID=labels.index[i]
                
            idx=np.where(Y==clusterID)
        
            plt.scatter(X[idx,0],X[idx,1],c=colors[clusterID%len(colors)],marker=markers[clusterID%len(markers)])
            
    #    plt.legend(loc=(1, 0))
            
        if bSubPlot==False:
             plt.show()    
      
        
        
            
        
        
    def AddNoise0(self,X,noiseRatio):
   
        nX=X.shape[0]
        nF=X.shape[1]
        
        noisedX=np.zeros((nX,nF))
        
        for i in range(X.shape[1]):
    #            _mean = np.mean(X[:,i])
            _var = np.var(X[:,i])
            _stdVar=np.sqrt(_var)
            
            #print(_mean,_var,_stdVar)
            
            
            noise=np.random.randn((nX))*_stdVar*noiseRatio
            
            noisedX[:,i]=X[:,i]+noise
        
        return noisedX
    
        
    def AddNoise(self,X,noiseRatio,covX=None):

        nX=X.shape[0]
        nF=X.shape[1]
        
        if nF>2000:         # out of menory
            return self.AddNoise0(X,noiseRatio) 

        if covX is None:
            covX=np.cov(X.T)       
        
        noise=np.random.multivariate_normal(np.zeros(nF,),covX,nX)*noiseRatio     
        
            
        return X+noise
            
            
   
    
            
    def GenerateXX(self, X,n,noiseRatio=0.1,noisingMethod='gaussian'):
        XX=[]
        XX.append(X)
        
        
        if noisingMethod=='gaussian':
            
            covX=None
            if X.shape[1]<=2000:
                covX=np.cov(X.T)
            
            for i in range(n):
                XX.append(self.AddNoise(X,noiseRatio,covX))     
                
        if noisingMethod=='category':      
            
            noising= NoisingForCategory()
            
            for i in range(n):
                XX.append(noising.AddNoiseToX(X,noiseRatio))  
                
                
        if noisingMethod=='noisingByNeighbours':      
            
            noising= NoisingByNeighbours()
            
            for i in range(n):
                XX.append(noising.AddNoiseToX(X,noiseRatio))  
                
                
        if noisingMethod=='combingGaussianAndNeighbours':      
            
            noising= NoisingByCombingGaussianAndNeighbours()
            
            for i in range(n):
                XX.append(noising.AddNoiseToX(X,self.ratio1,self.ratio2))  
                
                
            
            
        return XX
        
        
       #----------------------------------------
       
       
       
    
   
    
        
    def ClusteringXX(self,XX,clusteringMethod,k=-1):
        
        results=[]
        
        for i in range(len(XX)):
            
            try:
                
                if k>0:
                    clusterid=clusteringMethod(XX[i],k)
                else:
                    clusterid=clusteringMethod(XX[i])
               
                results.append(clusterid)
                
            except Exception as e:
                
                print('**********************************************')
                print('Error in clustering method ', clusteringMethod)
                print('Reason',e)
                print('**********************************************')
                
                raise RuntimeError('error in clustering method ', clusteringMethod)
                
                return results
                
            
        return results   
    
    
    
    def RunMethod(self,XX,Y,minK,maxK,clusteringMethod,clusteringName):
        
        bSuccess=True
         
        infos=[]
          
         
        for k in range(minK,maxK):       
                
                info={}
                
                try:
                    results=self.ClusteringXX(XX,clusteringMethod,k)   
                except:                               
                    bSuccess=False 
                    break                
              
                
                kernelSets=self.Kernel(results,len(XX)-1)
                
                if kernelSets is None:     # some algorithms can not get clustering results on some data
                    bSuccess=False 
                    break
                
    #            kernelSets=Kernel2(results,XXCount-1)
                
    #            print(kernelSets)
                
                information=self.Information(kernelSets,XX[0].shape[0])
                
                info['method']=clusteringName
                
                info['k']=k
                info['results']=results
               
          
                info['kernelSets']=kernelSets            
                info['information']=information   
                
                infos.append(info)  
            
        return [infos,bSuccess]
    #           
                
    
    
    
    def SaveEvaluationResults0(self,Y,infos,sortedIdx,filename):
        
        content= 'method,k,information,NMI,ARI,FMI,homogeneity,completeness,v_measure,stabilityScore,realK\n'
        
        realK=len(set(Y))
             
        for k in range(len(infos)):
            
            info=infos[sortedIdx[k]]
            
            self.Evaluation(info,Y,False)
                               
            content+="{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}\n".format(info['method'],info['k'],info['information'],info['NMI'],info['ARI'],info['FMI'],info['homogeneity'],info['completeness'],info['v_measure'],info['stabilityScore'],realK)
     
        fd = os.open(filename,os.O_RDWR|os.O_CREAT)
        
        os.write(fd,str.encode(content))
        
        os.close(fd)
        
        
        
        
    def SaveEvaluationResults(self,Y,savePath,infos,sortedIdx,infos2,sortedIdx2):
        
        if savePath!='':
            
            print('-------------save reulsts----------------')
            
            if os.path.exists(savePath)==False:
                os.makedirs(savePath)
            
            for i in range(200):
                filename=savePath+"/result"+str(i)
                if os.path.isfile(filename+"_all.csv")==False:   
                    break
            
#            self.SaveEvaluationResults0(Y,infos,sortedIdx,filename+"_1.csv")            
#            self.SaveEvaluationResults0(Y,infos2,sortedIdx2,filename+"_2.csv")
            
            if (infos is None) and (infos2 is None):
                return
            
               
            if ( not( infos2 is None) ) and (infos is None):  
                infos=infos2
            elif ( not( infos2 is None) ) and (not (infos is None)):  
                infos.extend(infos2)
            
                              
            allScores=np.zeros(len(infos))
            
            for j in range(len(infos)):                      
                allScores[j]=infos[j]['information']
                
            sortedIdx_all=np.argsort(allScores) 
            
            self.SaveEvaluationResults0(Y,infos,sortedIdx_all,filename+"_all.csv")    
            
            
            
            
        
    
    def OpCluster(self,X,Y=None,minK=2,maxK=16,savePath='',noiseRatio=0.1, noisingMethod='gaussian'):   
        

                
        XXCount=10
        
        XX=self.GenerateXX(X,XXCount-1,noiseRatio,noisingMethod)       
        
        infos=infos2=None
        sortedIdx=sortedIdx2=None
               
        if len(self.methods)>0:
           [infos,sortedIdx]= self.OpCluster1(XX,Y,minK,maxK,savePath)          
            
        if len(self.methods2)>0:
            [infos2,sortedIdx2]=self.OpCluster2(XX,Y)
            
            
        if not( (Y is None) or (savePath=='') ) :
            self.SaveEvaluationResults(Y,savePath,infos,sortedIdx,infos2,sortedIdx2)
        
            
            
                
               
                
        
        
    
    
    def OpCluster1(self,XX,Y=None,minK=2,maxK=16,savePath=''):                   
        
        
        scores_for_each_method=[]
        list_of_successful_method=[]
        infos=[]
        
          
        for clusteringName,clusteringMethod in self.methods.items():           
          
            print(' ')
            print('-------------',clusteringName,' running----------------')
            
            infoList, bSuccess=self.RunMethod(XX,Y,minK,maxK,clusteringMethod,clusteringName)
            
           
            
            if bSuccess==False:
                continue
            
            scores=np.zeros(len(infoList))
            
            for j in range(len(infoList)):                      
                scores[j]=infoList[j]['information']
                
            
            scores_for_each_method.append(scores)
            list_of_successful_method.append(clusteringName)
            
            for info in infoList:
                infos.append(info)
        
       
        #----------------------------------------
        
        if not self.FigureOff:
        
            plt.cla()
            
            _fontsize=14
            plt.xticks(fontsize=_fontsize)
            plt.yticks(fontsize=_fontsize)     
            plt.legend(fontsize=_fontsize)
    
            colors = ['r','g', 'b','c', 'y']    
            
            linestyles=['--','-','-.']
                
            plt.rcParams['figure.figsize'] = (8.0, 4.0) # 设置figure_size尺寸
            
            plt.figure()
            
            plt.xticks(np.arange(0, maxK+1, 1)) 
            
            for i in range(len(list_of_successful_method)):
                plt.plot(range(minK,maxK),scores_for_each_method[i],label=list_of_successful_method[i],color=colors[i%len(colors)],linestyle=linestyles[i%len(linestyles)])   
                
            leg = plt.legend(loc = 'best',fontsize=_fontsize)
            leg.get_frame().set_alpha(0.2)
            
            plt.xlabel('k',fontsize=_fontsize)
            plt.ylabel('information',fontsize=_fontsize)
                       
            
            plt.rcParams['savefig.dpi'] = 100 #图片像素
            plt.rcParams['figure.dpi'] = 300 #分辨率
            
           
            if len(savePath)>0:
                if os.path.exists(savePath)==False:
                    os.makedirs(savePath)
                savePath+='/'    
                
            plt.savefig(savePath+'opClustering.jpg', dpi=300)
            
            plt.show()
        
        
        
        #-------------------------suggestions for the clustering algorithm----------------------
        
        
        allScores=np.ones(len(infos))

        
        for i in range(len(infos)):
            allScores[i]=infos[i]['information']
            
        
        sortedIdx=np.argsort(allScores) 
        
        topK=min(3,len(allScores))
        
        print('----------- suggestions for clustering algorithms and parameters  -------------')
        
   
        
        for k in range(topK):    
            info=infos[sortedIdx[k]]
            print(info['method']+' k='+str(info['k'])+' information='+str(int(info['information'])) )
            
            if not(Y is None):              
                
                self.Evaluation(info,Y)
        
        return [infos,sortedIdx]
                
                  
                              
            
        
        
                
                           
    def OpCluster2(self,XX,Y=None):    
               
        
       
        infos=[]
        scores=[]
          
        for clusteringName,clusteringMethod in self.methods2.items():           
          
            print(' ')
            print('-------------',clusteringName,' running----------------')
            
            
            info={}
                
            try:
                results=self.ClusteringXX(XX,clusteringMethod)    
                    
            except:      
                
                break
            
             
            
            kernelSets=self.Kernel(results,len(XX)-1)
            
            if kernelSets is None:
                continue
            
#            kernelSets=Kernel2(results,XXCount-1)
            
#            print(kernelSets)
            
            information=self.Information(kernelSets,XX[0].shape[0])
            
            info['method']=clusteringName
            
            
            cSet=self.ClusteridToSet(results[0])           
                
            info['k']=len(cSet)
            
            info['results']=results
      
            info['kernelSets']=kernelSets            
            info['information']=information     
            
            infos.append(info)  
                
            scores.append(information)           
                   
        
        #-------------------------show the results ----------------------       
                           
        
        sortedIdx=np.argsort(scores) 
        
        print('----------- suggestions for clustering algorithms (type=2) and parameters  -------------')
        
   
        topK=min(3,len(scores))
        
        for k in range(topK):    
            
            info=infos[sortedIdx[k]]
            
            print(info['method']+' k='+str(info['k'])+' information='+str(int(info['information'])) )
            
            if not(Y is None):              
                
                self.Evaluation(info,Y)
             
            
        return [infos,sortedIdx]
                
                
                
                
        
        
    def Evaluation(self,info,Y,showOption=True):
        
        results=info['results']                       
        
        if info['k']<2:
            info['NMI']=info['ARI']=info['AvgScore']=info['FMI']=info['homogeneity']=info['completeness']=info['v_measure']=info['stabilityScore']=0
            
        else:            
                
            info['NMI']=round(metrics.normalized_mutual_info_score(Y,results[0]),2)
            info['ARI']=round(metrics.adjusted_rand_score(Y,results[0]),2)                           
            info['FMI']=round(metrics.fowlkes_mallows_score(Y,results[0]),2)
            info['homogeneity']=round(metrics.homogeneity_score(Y,results[0]),2) 
            info['completeness']=round(metrics.completeness_score(Y,results[0]),2) 
            info['v_measure']=round(metrics.v_measure_score(Y,results[0]),2)    
            info['stabilityScore']=round(self.ClusteringMeasurement(results),2)
              
        if showOption==True:            
            print('NMI=',info['NMI'],' ARI=',info['ARI'],' FMI=',info['FMI'])       
#            print('NMI=',info['NMI'],' ARI=',info['ARI'],' AvgScore=',info['AvgScore'])      
            print('homogeneity=',info['homogeneity'],' completeness=',info['completeness'],' v_measure=',info['v_measure'])                       
            print('stabilityScore=',info['stabilityScore'])
            print(' ')
                    
                
                        
            
          
       
    def MultipleClusteringWithNoise(self,X, k,noiseRatio=0.1, plot=True):    
        
        
        XX=self.GenerateXX(X,4,noiseRatio)               
        
        plt.rcParams['figure.figsize'] = (10.0, 2.0) # 设置figure_size尺寸
        
        for clusteringName,clusteringMethod in self.methods.items():           
              
            results=self.ClusteringXX(XX,clusteringMethod,k)    
            
            print(clusteringName+" "+"k="+str(k))   
    #        print(methods[i],k,score)   
            
            if plot==True:
                
                for n in range(5):
                    ax1 = plt.subplot(1,5,n+1) 
                    
                    if n==2:
                        plt.title(clusteringName+' k='+str(k))
                    ax1.set(aspect=1)
                    plt.sca(ax1)                
                    self.PlotClusters(XX[n],results[n],True)      
                    
               
    
                plt.savefig(clusteringName+'.jpg', dpi=300)
                plt.show()          
                
               
      
    def MultipleClusteringWithNoise2(self,X, k,noiseRatio=0.1, plot=True):    
        
        
        XX=self.GenerateXX(X,4,noiseRatio)               
        
        
        nMethods=len(self.methods)
        
        plt.rcParams['figure.figsize'] = (10.0, 2.0*nMethods) # 设置figure_size尺寸
        
        iRow=0
        
        idx=0
        
        for clusteringName,clusteringMethod in self.methods.items():           
              
            results=self.ClusteringXX(XX,clusteringMethod,k)    
            
            print(clusteringName+" "+"k="+str(k))   
    #        print(methods[i],k,score)   
            
            iRow=iRow+1
            
            if plot==True:
                
                for n in range(5):
                    
                    idx=idx+1
                    
                    ax1 = plt.subplot(iRow,5,idx) 
                    
                    if n==2:
                        plt.title(clusteringName+' k='+str(k))
                    ax1.set(aspect=1)
                    plt.sca(ax1)                
                    self.PlotClusters(XX[n],results[n],True)      
                    
               
    
                plt.savefig(clusteringName+'.jpg', dpi=300)
                plt.show()          
                
                         
            
                
    
    
    
    #---------------------------------------------------------------
    
    
    def ClusteringMeasurement(self,results,option=0):     
        
        totalScore=0
        count=0              
            
        if option==0:
            
            for i in range(len(results)):
                for j in range(i+1,len(results)):
                     score = metrics.normalized_mutual_info_score(results[i],results[j])   
                     
                     if score>1.001:
                         print('error: score=', score,i,j)
                         
                         print(pd.value_counts(results[i]))
                         
                         print(pd.value_counts(results[j]))
                         
                         score=0
                         
                     
                     totalScore=totalScore+score    
                     count=count+1     
        else:
           
            for j in range(1,len(results)):  
                
                 score = metrics.normalized_mutual_info_score(results[0],results[j])   
                 
                 if score>1.001:
                         print('error: score=', score,i,j)
                         
                         print(pd.value_counts(results[i]))
                         
                         print(pd.value_counts(results[j]))
                         
                         score=0
                 
                 totalScore=totalScore+score    
                 count=count+1   
        
        return totalScore/count
        
       
       
    
    
    
    def ClusteringMeasurementByRealY(self,results,Y):     
        
        totalScore=0
        count=0
       
        for j in range(len(results)):
             score = metrics.normalized_mutual_info_score(Y,results[j])             
             totalScore=totalScore+score    
             count=count+1   
             
        
        return totalScore/count
        
    
    
    
    
    def ClusteridToSet(self,clusterid):
        
        clusterSet=[]
        
        labels=pd.value_counts(clusterid)   
        
        for i in range(len(labels)):
            
            clusterID=labels.index[i]
            
            if clusterID==-1:
                continue
            
            idx=np.where(clusterid==clusterID)
            
            clusterSet.append(set(idx[0]))
            
        return clusterSet
            
            
            
         
    def MaxIntersection(self,rscSet,dstSets,flag):
        
        maxIntersection=0
        
        maxIdx=0
        
        for i in range(len(dstSets)):
            if flag[i]==0:     
                    
                intersectionSet=rscSet&dstSets[i]
                
                if len(intersectionSet)>=maxIntersection:
                    maxIntersection=len(intersectionSet)
                    maxIdx=i
                    
        return [maxIdx,rscSet&dstSets[maxIdx]]
                    
                
    
        
    def Kernel(self,results,count):
     
          
        cSet0=self.ClusteridToSet(results[0])      
        
        ck=len(cSet0)
        
        sets=[]
        
        for i in range(1,len(results)):
            
            cSet=self.ClusteridToSet(results[i])
            
            for j in range(len(cSet)):
                sets.append(cSet[j])   
            
            #-------------for the algorithms such as meanshift, AP,-----
            if ck!=len(cSet) and( (ck<5) or (len(cSet)<5) ):
                return None                   
            #----------------------        
        
        kernelSets=[]
        
        
        
        for k in range(len(cSet0)):        
        
            rscSet=cSet0[k]             
            
            flag=np.zeros(len(sets))
            
            for i in range(count-1):
                maxIdx,rscSet=self.MaxIntersection(rscSet,sets,flag)
                flag[maxIdx]=1

            
            if(len(rscSet)>1):  # for AP clustering, its clusters always contain only one point
                kernelSets.append(rscSet)    
            
            
        return kernelSets
            
            
    
    
    
    
    def Information(self,kernelSets,totalCount):
        
        info=0
        
        numberInCluster=0
        
        for i in range(len(kernelSets)):
            count=len(kernelSets[i])
            numberInCluster+=count
           
        numberNotInCluster=totalCount-numberInCluster
        
        if numberNotInCluster>0:
            info+=-numberNotInCluster*np.log2(1/totalCount)      
        

        
        for i in range(len(kernelSets)):
            count=len(kernelSets[i])       
            info+=-count*np.log2(1/(count+numberNotInCluster))
            
            

            
        return info
        
        
    
    
    
    
    
    
    
    
    
    
    
    
#-------------------------------------------
        

def score_and_rank(df, idx):
    
    scores=df.iloc[:,idx]
    
    score=scores[0]
    
    scores[0]+=0.001    # in case of the instability of sorting
    
    sortedIdx=np.argsort(-scores) 
    
    for k in range(len(scores)):
        if sortedIdx[k]==0:
            return [score,k+1]
        
    return [score,1]
    
    
        
    
def StatisticalAnalysis(dataset,start=0,end=10,postfix=''):
    
    score_rank_ARI=np.array([0,0])
    score_rank_NMI=np.array([0,0])
    
    nMethods=1
    
    count=0
    
    hits=np.array([0,0])
    
    noFileCount=0
    
    predictK=0
    
    stdK=0
    
    for i in range(start,end,1):               
        
        
        filename=dataset+"/result"+str(i)+"_all.csv"          
        
        if os.path.isfile(filename)==False:   
            noFileCount+=1
            continue
        
        if noFileCount>30:
            break
        
        df=pd.read_csv(filename,sep=',')  
        
        #----------------------------------  
        
        nMethods=df.shape[0]
       
        score_rank_ARI=score_rank_ARI+np.array(score_and_rank(df,4))
        score_rank_NMI=score_rank_NMI+np.array(score_and_rank(df,3))
        
        
        count+=1
        
        #--------------------------------
        realK=int(df['realK'][0])
        predictK+=float(df['k'][0])
        
        
        stdK+=(float(df['k'][0])-realK)*(float(df['k'][0])-realK)
        
        ks=df['k'][0:3]
    
        if ks[0]==realK:
            hits[0]+=1
        
        
        if (ks[0]==realK) or (ks[1]==realK) or (ks[2]==realK):
            hits[1]+=1
        
    #-------------------------------------
    
   
    
    if count>0:
        
        predictK=round(predictK/count,1)
        
        stdK=round(np.sqrt(stdK/count),2)
        
        score_rank_ARI=np.round(score_rank_ARI/count,2)
        score_rank_NMI=np.round(score_rank_NMI/count,2)
        
        content='dataset,rank_ARI,avg_ARI,rank_NMI,avg_NMI,nMethods,top1HitK,top3HitK,#tests,realK,predictK,stdK\n'
        
        content+="{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}".format(dataset,np.round(score_rank_ARI[1],1),score_rank_ARI[0],np.round(score_rank_NMI[1],1),score_rank_NMI[0],nMethods,int(hits[0]*100/count),int(hits[1]*100/count),count,realK,predictK,stdK)
        
        print(content)
        
        fd = os.open(dataset+'/statistic'+postfix+'.csv',os.O_RDWR|os.O_CREAT)
    
        os.write(fd,str.encode(content))
    
        os.close(fd)
    



   
    
def CombineStatisticalAnalysis( rootdir = './'):
    
#    rootdir = './'   # 需要遍历的文件夹，这里设定为当前文件夹

    dataframes=[]
    # 如果此循环在迭代第一次时break出，则其效果和上面的相同
    for root, dirs, files in os.walk(rootdir):    # 当前路径、子文件夹名称、文件列表
#        for filename in files:
#            print (filename)
        for dirname in dirs:            
            
            resultFile=dirname+'/statistic.csv'
            
            if os.path.isfile(resultFile)==True: 
                try:
                    df=pd.read_csv(resultFile,sep=',')
                    
                    print(dirname, ' done')
                except Exception as e:
                    print(e)
                    continue
                 
                dataframes.append(df)
        
    combinedResults = pd.concat(dataframes)
   
    combinedResults.to_csv('combinedStatisticlResults.csv', sep=',', encoding='utf-8')






#-------------------------------for test ----------------------------------
    
   
    
    
def CirclePoints(x0,y0,r,n):
  
    X=np.zeros((n,2))
#    X[:,0]=np.random.uniform(low=x0-r,high=x0+r,size=n)
    
    
    angle=np.arange(0,360,360/n)        
        
    X[:,0]=x0+r*np.cos(angle)  
    
    X[:,1]=x0+r*np.sin(angle)  

           
    return X


#-----------------------------
    





def load_mnist(path, kind='train'):
    """Load MNIST data from `path`"""
#    labels_path = os.path.join(path,
#                               '%s-labels-idx1-ubyte'
#                               % kind)
#    images_path = os.path.join(path,
#                               '%s-images-idx3-ubyte'
#                               % kind)
    
    labels_path = os.path.join(path,
                               '%s-labels.idx1-ubyte'
                               % kind)
    images_path = os.path.join(path,
                               '%s-images.idx3-ubyte'
                               % kind)
    
    
    with open(labels_path, 'rb') as lbpath:
        magic, n = struct.unpack('>II',
                                 lbpath.read(8))
        labels = np.fromfile(lbpath,
                             dtype=np.uint8)

    with open(images_path, 'rb') as imgpath:
        magic, num, rows, cols = struct.unpack('>IIII',
                                               imgpath.read(16))
        images = np.fromfile(imgpath,
                             dtype=np.uint8).reshape(len(labels), 784)

    return images, labels



def LoadData(sample_str):
        
    X=Y=None
    
   
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    extension=os.path.splitext(sample_str)[-1] 
    
 
    
    if datasetName == 'k5':        
        X, Y = make_blobs(n_samples=100, n_features=2, centers=5,random_state=3)
        
    if datasetName == 'k10':        
        X, Y = make_blobs(n_samples=600, n_features=10, centers=10,random_state=3)
        
    if datasetName == 'k15':        
        X, Y = make_blobs(n_samples=600, n_features=15, centers=15,random_state=3)
    
    if datasetName == 'dualCircles':
       
        n=100
        X0=CirclePoints(5,5,5,n)
        Y0=np.zeros(n,dtype='int')
        
        X1=CirclePoints(5,5,2.5,n)
        Y1=np.ones(n,dtype='int')
#      
        
        X=np.vstack((X0,X1))       
        Y=np.hstack((Y0,Y1))   
#       
        
    if datasetName == 'pc3':      
        
        n=50
        X0=np.zeros((n,2))
        X0[:,0]=np.arange(0,10,0.2)
        X0[:,1]=1*X0[:,0]
        Y0=np.ones(n,dtype='int')*0
        
      
        X1=np.zeros((n,2))
        X1[:,0]=np.arange(0,10,0.2)
        X1[:,1]=2*X1[:,0]
        Y1=np.ones(n,dtype='int')*1
        
        X2=np.zeros((n,2))
        X2[:,0]=np.arange(0,10,0.2)
        X2[:,1]=-1*X2[:,0]
        Y2=np.ones(n,dtype='int')*2
        
        X=np.vstack((X0,X1,X2))       
        Y=np.hstack((Y0,Y1,Y2))   
        
        
    
    if datasetName == 'Iris':
        sample = datasets.load_iris()
        X = sample.data
        Y = sample.target
        
    if datasetName == 'ecoli':
      
        filename='dataset/ecoli.csv'
        data = pd.read_csv(filename, header=None)
        
        
        data = data.values
        # split into input and output elements
        X, y = data[:, :-1], data[:, -1]
        # label encode the target variable to have the classes 0 and 1
        Y = LabelEncoder().fit_transform(y)
        
    if datasetName == 'Wine':
        sample = datasets.load_wine()
        X = sample.data
        Y = sample.target       
        
    if datasetName == 'Car Evaluation':
        df = pd.read_csv('dataset/car.csv')
        df2=np.array(df)        
        X=df2[:,1:7]
        Y=df2[:,7]
        
    if datasetName == 'Digits':
        sample = datasets.load_digits()
        X = sample.data
        Y = sample.target
    
    if extension == '.mat':        
#        
        path='dataset/'   
        data = scio.loadmat(path+sample_str)        
        X=data['data']
        Y=data['label']
        Y=Y.reshape(-1,)
        Y=np.array(Y,dtype=int)
        
    if (datasetName == 'winequality-red') or (datasetName == 'winequality-white'):
                
        columns = ["facidity", "vacidity", "citric", "sugar", "chlorides", "fsulfur", 
                       "tsulfur", "density", "pH", "sulphates", "alcohol", "quality"]
        
#        "http://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"
#        "http://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-white.csv"
        
        wines=pd.read_csv("http://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/"+sample_str+".csv",
                             names=columns, sep=";", skiprows=1)
        
   
       
        wines=np.array(wines,dtype=float)
        X=wines[:,0:11]
        Y=wines[:,11]
        Y=np.array(Y,dtype=int)     
    
    if extension=='.arff':  
        
        path='dataset/ARFF/'     
        
        
        try:
            
            data = arff.loadarff(path+sample_str)
    
            df = pd.DataFrame(data[0])
            
            # df.columns
            
        except Exception as e:              
        
            # Read the file as text and specify the encoding
            with open(path + sample_str, 'r', encoding='utf-8') as f:
                arff_text = f.read()
        
            # Decode the text into a format that loadarff can handle
            arff_decoded = io.StringIO(arff_text)
        
            # Load the decoded text using loadarff
            data = arff.loadarff(arff_decoded)
        
            df = pd.DataFrame(data[0])
    
    
        
        try:
            
            for name in data[1]._attrnames:
                if data[1]._attributes[name][0]=='nominal':
                    df[name]=preprocessing.LabelEncoder().fit_transform(df[name])
        except Exception as e:            
            print(sample_str, 'does not include the description of attrnames or _attributes')
           
        classStr=''
        
        if 'class' in df.columns:
            classStr='class'
            
        if 'CLASS' in df.columns:
            classStr='CLASS'
        
        if classStr!='':
            
            cX=df.loc[:,df.columns != classStr]
            cY=df[classStr]  
            
            X=np.array(cX)
            Y=np.array(cY,dtype=int)             
        
        
    if sample_str=='TCGA-PANCAN-HiSeq':
        
               
        df_x = pd.read_csv('dataset/TCGA-PANCAN-HiSeq/data.csv')
        
        df_y = pd.read_csv('dataset/TCGA-PANCAN-HiSeq/labels.csv')        
       
        cX=df_x.loc[:,df_x.columns !=df_x.columns[0]]           
        
        cY=preprocessing.LabelEncoder().fit_transform(df_y['Class'])
        
        X=np.array(cX)
        Y=np.array(cY,dtype=int)       
        
        
    if(datasetName == 'olivetti_faces'):

        olivetti_faces_x_file="dataset/olivetti/olivetti_X.csv"
        olivetti_faces_y_file="dataset/olivetti/olivetti_Y.csv"
        
        if os.path.isfile(olivetti_faces_y_file)==False:            
            olivetti = fetch_olivetti_faces()
            x = olivetti.images
            y = olivetti.target            
            
            # Print info on shapes and reshape where necessary
            print("Original x shape:", x.shape)
            X = x.reshape((400, 4096))
            print("New x shape:", X.shape)
            print("y shape", y.shape)
            
            # Save the numpy arrays
            Y=y
            np.savetxt(olivetti_faces_x_file, X, delimiter = ",")
            np.savetxt(olivetti_faces_y_file, Y, delimiter = ",", fmt = '%d')
            
            print("\nDownloading and reshaping done!")
        else:            
            
            X = np.loadtxt(olivetti_faces_x_file, delimiter = ",")                        
        
            Y = np.loadtxt(olivetti_faces_y_file, delimiter = ",")
            Y=Y.astype(np.int)
          
            X=X[0:100,:]
            Y=Y[0:100,]
    
    if(datasetName == 'MNIST'): 
        
#        train_images = mnist.train_images()
#        train_labels = mnist.train_labels()
        
        [train_images,train_labels]=load_mnist('dataset\MNIST')
        

        XX=np.reshape(train_images,(60000,28*28))
        
        count=200
        
        X=np.array(XX[0:count,:])
        
        Y=np.array(train_labels[0:count,],int)


    if (datasetName == 'Levine_13dim') or  (datasetName =='Levine_13dim_notransform'):
      
#        datasetName = 'Levine_13dim'
        df = pd.read_csv('dataset/FlowRepository/'+datasetName+'.csv')
        df2=np.array(df)     
        nF=df2.shape[1]-1
        X=df2[:,0:nF]
        Y=np.array(df2[:,nF],int)

    

   
    if (sample_str.endswith('.all_features.txt')) or  (sample_str.endswith('.seled_features.txt')):
        
       
        file=''
        
        if (sample_str.endswith('.all_features.txt')):
            file='dataset/dataset1_all_features/'+sample_str
        else:
            file='dataset/dataset2_chosen_feaures/'+sample_str
        
        df = pd.read_csv(file,'\t')

        df2=np.array(df)
        
        nF=df2.shape[1]-1
        
        X=df2[:,1:nF]     
        
        X=np.array(X,float)
        
        Y=np.array(df2[:,nF],int)
        
        

    if not Y is None:
        print('nX=',X.shape[0],' nF=',X.shape[1],' k=',len(set(Y)))     
        print('cluster size=',np.bincount(Y))

                
    return [X,Y]



#---------------------------------------------------
    



def TestDataset(dataset,minK=2,maxK=15,FigureOff=False,noiseRatio=0.1,noisingMethod='gaussian'):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        

        
    
    #--------------method type=2-----------------
    op.methods2={}
    
    op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
    
    op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_0.4',cluster.DBSCAN(eps = 0.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.6',cluster.DBSCAN(eps = 0.6).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.0',cluster.DBSCAN(eps = 1.0).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_1.2',cluster.DBSCAN(eps = 1.2).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.4',cluster.DBSCAN(eps = 1.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
##        
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0],noiseRatio=noiseRatio,noisingMethod=noisingMethod)
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数

#-----------------------------------------------
    
    
    






def Analysis():    

    filePath = 'dataset/ARFF/'
    arff_datasets=os.listdir(filePath)
    
    datasets=['k5','k10','k15','dualCircles','gaussian.mat','Iris','Wine','Car Evaluation','winequality-red', 'olivetti_faces','TCGA-PANCAN-HiSeq','MNIST','Levine_13dim','Levine_13dim_notransform']  #the dataset contains 20000 features and runs slowly
    
    datasets.extend(arff_datasets)
    
    
    for i in range(len(datasets)):
            
        dataset=datasets[i]
        
        StatisticalAnalysis(os.path.splitext(dataset)[0])
            
    CombineStatisticalAnalysis()


#---------------------------------

def TestAllDatasets():    
    
    filePath = 'dataset/ARFF/'
    arff_datasets=os.listdir(filePath)
    
    datasets=['k5','k10','k15','dualCircles','gaussian.mat','Iris','Wine','Car Evaluation','winequality-red', 'TCGA-PANCAN-HiSeq','olivetti_faces','Levine_13dim','Levine_13dim_notransform']  #the dataset contains 20000 features and runs slowly

    
    datasets.extend(arff_datasets)
    
    
    start=random.randint(1,len(datasets))
    
    #start=0
    
    for k in range(5):
        
        for i in range(len(datasets)):
            
            dataset=datasets[(i+start)%len(datasets)]
                       
            try:
                TestDataset(dataset,FigureOff=True)
            
            except Exception as e:
                
                print(dataset,e)
                continue
            
             
#----------------------------------------------------------------




def TestATCG(dataset='TCGA-PANCAN-HiSeq',minK=2,maxK=15,FigureOff=False):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        
    
#    #--------------method type=2-----------------
#    op.methods2={}
#    
#    op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
#    
#    
#    op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
#    op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
#    op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
#    
#    op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
#    op.AddClusteringMethod('DBSCAN_0.4',cluster.DBSCAN(eps = 0.4).fit_predict, methodType=2) 
#    op.AddClusteringMethod('DBSCAN_0.6',cluster.DBSCAN(eps = 0.6).fit_predict, methodType=2) 
#    op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
#    op.AddClusteringMethod('DBSCAN_1.0',cluster.DBSCAN(eps = 1.0).fit_predict, methodType=2)  
#    op.AddClusteringMethod('DBSCAN_1.2',cluster.DBSCAN(eps = 1.2).fit_predict, methodType=2) 
#    op.AddClusteringMethod('DBSCAN_1.4',cluster.DBSCAN(eps = 1.4).fit_predict, methodType=2) 
#    op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
##        
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0])
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数



#-----------------------------------------------
    
    

def TestFlow(dataset,minK=2,maxK=15,FigureOff=False):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
     
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0])
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数



#-----------------------------------------------
    
            
#Analysis()
#
#TestAllDatasets()
                
#TestDataset('TCGA-PANCAN-HiSeq')
#TestDataset('banana.arff')
                
def  MultipleClusteringWithNoise(dataset='dualCircles',k=2):
          
    [X,Y]=LoadData(dataset)
    
    op=OPClustering()
    #
    op.FigureOff=False
    
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
   
        
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
    #    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
    #    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
    #    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
    #    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
    #    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
  
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
    
    
                
    op.MultipleClusteringWithNoise(X,k)
    
    rscImages=[]
    for clusteringName,clusteringMethod in op.methods.items():   
        
        rscImages.append(clusteringName+'.jpg')
        
#    CombineImages2(path='',rscImages=rscImages,option='v') #调用函数          
#          
#
#MultipleClusteringWithNoise(dataset='dualCircles',k=3)   
#
##------------------------------

def olivetti_faces_science():
    oY=np.zeros((100,))    
    
    for i in range(100):
        oY[i]=int(i/10)

    Y=np.zeros((100,))  
    
    Y[10]=Y[12]=Y[14]=Y[16]=Y[17]=Y[19]=1
    Y[30]=Y[32]=Y[37]=2
    Y[40]=Y[43]=Y[46]=3
    Y[50]=Y[51]=Y[52]=4
    Y[53]=Y[54]=Y[55]=Y[56]=Y[59]=5
    Y[60]=Y[61]=Y[62]=Y[63]=Y[64]=Y[65]=Y[66]=Y[67]=Y[68]=Y[69]=6
    Y[72]=Y[74]=Y[75]=Y[77]=7
    Y[80]=Y[81]=Y[82]=8
    Y[91]=Y[94]=Y[95]=Y[97]=9
    
    info={}
    info['NMI']=round(metrics.normalized_mutual_info_score(oY,Y),2)
    info['ARI']=round(metrics.adjusted_rand_score(oY,Y),2)                           
    info['FMI']=round(metrics.fowlkes_mallows_score(oY,Y),2)
    info['homogeneity']=round(metrics.homogeneity_score(oY,Y),2) 
    info['completeness']=round(metrics.completeness_score(oY,Y),2) 
    info['v_measure']=round(metrics.v_measure_score(oY,Y),2)    
  
  
    





#----------------------------------------------------------------------------------------------------



def main(argv):   
    print('running.........')
    
    if len(sys.argv)>1:
        if str(sys.argv[1])=='Analysis':
            print('Analysis')
            Analysis()
            
        elif str(argv[1])=='TestAllDatasets':           
            TestAllDatasets()
            
        elif str(argv[1])=='Test':    
            if len(sys.argv)==5:
                TestDataset(argv[2],int(argv[3]),int(argv[4]))
            elif len(sys.argv)==8:
                TestDataset(dataset=argv[2],minK=int(argv[3]),maxK=int(argv[4]),FigureOff=(argv[5]=='True'), noiseRatio=float(argv[6]),noisingMethod=argv[7])
            else:
                TestDataset(argv[2])
        elif str(argv[1])=='TestATCG':
            TestATCG()  
            
        elif str(argv[1])=='TestFlow':
            TestFlow(argv[2])  
        elif str(argv[1])=='StatisticalAnalysis':
            StatisticalAnalysis(argv[2],start=int(argv[3]),end=int(argv[4]),postfix=argv[5]) 


if __name__ == '__main__':
    main(sys.argv)
















#------------------------------------for test-----------------------------------------------




def TestDataset2(dataset,minK=2,maxK=15,FigureOff=False,noiseRatio=0.1,noisingMethod='gaussian'):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        

        
    
    #--------------method type=2-----------------
    op.methods2={}
    
    # op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    # op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    # op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    # op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
    
    # op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    # op.AddClusteringMethod('DBSCAN_0.4',cluster.DBSCAN(eps = 0.4).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_0.6',cluster.DBSCAN(eps = 0.6).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_1.0',cluster.DBSCAN(eps = 1.0).fit_predict, methodType=2)  
    # op.AddClusteringMethod('DBSCAN_1.2',cluster.DBSCAN(eps = 1.2).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_1.4',cluster.DBSCAN(eps = 1.4).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
##        
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0],noiseRatio=noiseRatio,noisingMethod=noisingMethod)
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数

#-----------------------------------------------
    
    

    
def TestDataset111(sample_str,minK=2,maxK=12):
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    for i in range(10):
        TestDataset2(sample_str, minK, maxK,True, 0.25,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,0,10,'neighbour_0.25')
    
    for i in range(10):
        TestDataset2(sample_str, minK,maxK,True, 0.5,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,10,20,'neighbour_0.5')
    
    for i in range(10):
        TestDataset2(sample_str, minK, maxK,True, 1,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,20,30,'neighbour_1')
    
    for i in range(10):
        TestDataset2(sample_str, minK,maxK,True, 2,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,30,40,'neighbour_2')
    
    for i in range(10):
        TestDataset2(sample_str, minK, maxK,True, 3,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,40,50,'neighbour_3')
    
    for i in range(10):
        TestDataset2(sample_str, minK,maxK,True, 4,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,50,60,'neighbour_4')
    
    
# TestDataset111("Iris")    
# TestDataset111("ecoli.arff")    
# TestDataset111("k5") 
    
    
def TestDataset22(sample_str,minK=2,maxK=12):
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    for i in range(10):
        TestDataset2(sample_str, minK, maxK,True, 2,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,0,10,'neighbour_2')
    
    for i in range(10):
        TestDataset2(sample_str, minK,maxK,True, 3,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,10,20,'neighbour_3')
    
 
    
testDatasets=['diamond9.arff','twenty.arff','k5','k10','k15','wdbc','ecoli.arff','banana.arff','2dnormals.arff','smile3.arff','disk-3000n.arff','R15.arff','balance-scale.arff']

def TestDataset222():
    
    for dataset in testDatasets:
        
        TestDataset22(dataset)
        
        
# TestDataset222()




def TestDataset3(dataset,minK=2,maxK=15,FigureOff=False,noiseRatio=0.1,noisingMethod='gaussian'):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        

        
    
    #--------------method type=2-----------------
    op.methods2={}
    
    op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
    
    op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_0.4',cluster.DBSCAN(eps = 0.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.6',cluster.DBSCAN(eps = 0.6).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.0',cluster.DBSCAN(eps = 1.0).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_1.2',cluster.DBSCAN(eps = 1.2).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.4',cluster.DBSCAN(eps = 1.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
        
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0],noiseRatio=noiseRatio,noisingMethod=noisingMethod)
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数

#-----------------------------------------------
    
    
    
    
    
def TestDataset33(sample_str,minK=2,maxK=15):
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    for i in range(10):
        TestDataset3(sample_str, minK, maxK,True, 2,'noisingByNeighbours')
        
    # StatisticalAnalysis( datasetName,0,10,'neighbour_2')
    

    
 
    
testDatasets=['diamond9.arff','twenty.arff','k5','k10','k15','wdbc','ecoli.arff','banana.arff','2dnormals.arff','smile3.arff','disk-3000n.arff','R15.arff','balance-scale.arff']

def TestDataset333():
    
    for dataset in testDatasets:
        
        TestDataset33(dataset)
        
        
# TestDataset333()




   
    
def CombineStatisticalAnalysis2( rootdir = './',rFile='statistic_neighbour_2.csv',combineResultFile='combinedStatisticlResults_N2.csv'):
    
#    rootdir = './'   # 需要遍历的文件夹，这里设定为当前文件夹

    dataframes=[]
    # 如果此循环在迭代第一次时break出，则其效果和上面的相同
    for root, dirs, files in os.walk(rootdir):    # 当前路径、子文件夹名称、文件列表
#        for filename in files:
#            print (filename)
        for dirname in dirs:            
            
            
            print(dirname)
             
            resultFile=dirname+'/'+rFile
            
            print(resultFile)
            
            if os.path.isfile(resultFile)==True: 
                try:
                    df=pd.read_csv(resultFile,sep=',')
                    
                    print(dirname, ' done')
                except Exception as e:
                    print(e)
                    continue
                 
                dataframes.append(df)
        
    combinedResults = pd.concat(dataframes)
   
    combinedResults.to_csv(combineResultFile, sep=',', encoding='utf-8')


# CombineStatisticalAnalysis2()

# CombineStatisticalAnalysis2(rootdir = './',rFile='statistic_neighbour_3.csv',combineResultFile='combinedStatisticlResults_N3.csv')






#----------------------------------







def TestDataset5(dataset,minK=2,maxK=15,root='',FigureOff=False,noisingMethod='combingGaussianAndNeighbours',ratio1=0.05, ratio2=1):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
      
    op.ratio1=ratio1
    op.ratio2=ratio2
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        

        
    
    #--------------method type=2-----------------
    op.methods2={}
    
    op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
    
    op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_0.4',cluster.DBSCAN(eps = 0.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.6',cluster.DBSCAN(eps = 0.6).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.0',cluster.DBSCAN(eps = 1.0).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_1.2',cluster.DBSCAN(eps = 1.2).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.4',cluster.DBSCAN(eps = 1.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
        
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=root+os.path.splitext(dataset)[0],noiseRatio=ratio1,noisingMethod=noisingMethod)
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数


    

#-----------------------------------------------



    

s5dataSets=["2d-10c.arff","2d-4c-no4.arff","2dnormals.arff","banana.arff","chainlink.arff","complex8.arff","curves2.arff","Iris","Wine"]

def TestDataset55(sample_str,minK=2,maxK=15,root='',ratio1=0.05, ratio2=1):
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    for i in range(10):
        TestDataset5(sample_str, minK, maxK,root,True, "combingGaussianAndNeighbours",ratio1,ratio2)
        
        

def TestDataset555(ratio1=0.05, ratio2=1):
    
    for sample_str in s5dataSets:
        
        root=str(ratio1)+"_"+str(ratio2)+"\\"
        
        TestDataset55(sample_str,2,15,root,ratio1,ratio2)
        
    Analysis()
        

# TestDataset555(0.03,0.7)
        
# TestDataset555(0.03,1)

# TestDataset555(0.03,1.3)

# TestDataset555(0.05,0.7)
        
# TestDataset555(0.05,1)

# TestDataset555(0.05,1.3)

# TestDataset555(0.07,0.7)
        
# TestDataset555(0.07,1)

# TestDataset555(0.07,1.3)







def MultipleNosedDatasets(dataset='3-spiral.arff',minK=2,maxK=15,FigureOff=False):
    
    
   
    [X,Y] = LoadData(dataset)  
    
    # if X is None:
    #     return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    # op.AddClusteringMethod('spectral gamma=0.25',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
         
    op.MultipleClusteringWithNoise(X,15,0.1,True)
     
    
   


def Analysis2():    

    filePath = 'C:/Users/77994/Desktop/OPClusteringNN/dataset/ARFF/'
    arff_datasets=os.listdir(filePath)
    
    datasets=['k5','k10','k15','dualCircles','gaussian.mat','Iris','Wine','Car Evaluation','winequality-red', 'olivetti_faces','TCGA-PANCAN-HiSeq','MNIST','Levine_13dim','Levine_13dim_notransform']  #the dataset contains 20000 features and runs slowly
    
    datasets.extend(arff_datasets)
    
    
    for i in range(len(datasets)):
            
        dataset=datasets[i]
        
        StatisticalAnalysis(os.path.splitext(dataset)[0])
            
    CombineStatisticalAnalysis()
    
    
# Analysis2()

