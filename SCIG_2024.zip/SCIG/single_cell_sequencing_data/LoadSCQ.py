# -*- coding: utf-8 -*-
"""
Created on Wed Sep 28 11:12:17 2022

@author: 77994
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 29 15:04:09 2022

@author: 77994
"""





import numba as nb
  
import numpy as np



import time    
from sklearn import metrics    

import pandas as pd 



import datetime

from sklearn.preprocessing import LabelEncoder





from sklearn.model_selection import train_test_split



from sklearn.preprocessing import LabelEncoder


from collections import Counter



from sklearn.metrics import adjusted_rand_score


from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import pairwise_distances

from sklearn.mixture import GaussianMixture

from sklearn.cluster import SpectralClustering

import scipy 


import warnings

warnings.filterwarnings("ignore")

#--------------------------------Load single cell sequencing data--------------------------------------------
    
    


scq_datasets = [    
    'Klein',
    'Kumar',
    'KumarTCC',  
]


SCQ_PATH='data\\'



class LoadSingleCellSequencing:
    
    @staticmethod   
    def LoadData(datasetName):
        
        X=Y=None     
        
        if datasetName in scq_datasets:     
            
            path_x = SCQ_PATH+'danxibao_csv\\'+datasetName+'.csv'
            path_y = SCQ_PATH+'danxibao_label\\'+datasetName+'.csv'
            
            data = pd.read_csv(path_x).iloc[:, 1:]
            
            label = pd.read_csv(path_y)['label']
            label = np.array(label).reshape(-1, 1)
         
            ###########################     #把字符类标签数字化
            lab = LabelEncoder()
            lab.fit(label)
            label = lab.transform(label)
        
            ###########################
        
        
            ###########################     #如果数据规格不合适，则进行转置
            if label.shape[0] == data.shape[1]:
                data = data.T
        
            ############################
            
            X=np.array(data,dtype=float)
            Y=label        
            
            print('nX=',X.shape[0],' nF=',X.shape[1],' k=',len(set(Y)))      
                
        return [X,Y]
    
    
#----------------------------------------------------------------------------------------------------
        
    
    
    
    
    
    
    
    
    
    
    