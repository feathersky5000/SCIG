python 3.7.4

required package:   sklearn,  scipy ，scanpy



1. Users can run the run.bat to reproduce the experiments (for single_cell_sequencing_data) in the paper. 






 

