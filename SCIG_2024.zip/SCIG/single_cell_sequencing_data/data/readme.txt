The data file has been uploaded as a separate file. The data file is relatively large, and GitHub does not allow uploading files exceeding 25M.




 

