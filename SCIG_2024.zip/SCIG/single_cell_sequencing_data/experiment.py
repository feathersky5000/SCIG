# -*- coding: utf-8 -*-
"""
Created on Mon Oct  9 08:54:13 2023

@author: Xiaojun Ding
"""






import numpy as np


import scanpy as sc


from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
    

from LoadSCQ import LoadSingleCellSequencing


from SCQ_Clustering import SCQ_Clustering

from collections import Counter


from sklearn.metrics import accuracy_score





import sys

from datetime import datetime



# from sklearn.utils.linear_assignment_ import linear_assignment



def ProcessData(adata,n_top_genes,n_pcs=10):
    
    # 数据预处理
    # Filter out low-quality cells and genes
    sc.pp.filter_cells(adata, min_genes=100)
    sc.pp.filter_genes(adata, min_cells=3)
    
    
    try:           
        sc.pp.highly_variable_genes(adata, flavor='seurat_v3', n_top_genes=n_top_genes)  # 选择要保留的可变特征数量
    except Exception as e:
        print(e)
        
       
       
    # sc.pp.normalize_total(adata, target_sum=1e4)  # 归一化
    sc.pp.log1p(adata)  # 对数变换    
    
    # 运行PCA
    sc.tl.pca(adata, n_comps=n_pcs)  # n_comps是要保留的主成分数量，根据需要进行调整
    
    
  




class Log:
    
    filename="log.txt"
    
    @staticmethod  
    def Record(*args):       
       
         with open(Log.filename, "a") as file:
            output_str = " ".join(map(str, args))
            file.write(output_str + "\n")
        
            
         print(args)
        
        
        
        
    @staticmethod  
    def RecordWithTime(*args):
        
        with open(Log.filename, "a") as file:
            
           output_str = " ".join(map(str, args))          
           
           file.write('\n'+str(datetime.now()) + "\n")
           file.write(output_str + "\n")
       
           
        print(args)
            
        
    


def PrecisionOfSubsets(reliableSubsets,Y):
    
    
    n_clusters=len(reliableSubsets)    
    
    total_samples_in_subset=0
    correct_labels_in_subset=0
    
    for i in range(n_clusters):       
        
        subset=reliableSubsets[i]
        
        subset_labels=Y[list(subset)]
        
        
        # 使用 Counter 统计元素出现次数
        counter = Counter(subset_labels)
        
        # 获取出现次数最多的元素和次数
        most_common_element, count = counter.most_common(1)[0]        
        
        idx=np.where(Y==most_common_element)        
        
        print('label=',most_common_element, 'count(realY)=', len(idx[0]), 'subset=',len(subset), 'precision=', round(count/len(subset),3) )
        
        total_samples_in_subset+=len(subset)
        correct_labels_in_subset+=count
        
    print('total precision=', round(correct_labels_in_subset/total_samples_in_subset,3) )
        
        



def map_cluster_labels(predict_y, y):
    """
    将聚类标签映射到真实标签
    
    Parameters:
        predict_y (array-like): 聚类算法的预测标签
        y (array-like): 真实标签
    
    Returns:
        dict: 映射关系字典
    """
    unique_clusters = np.unique(predict_y)
    label_mapping = {}

    for cluster_label in unique_clusters:
        cluster_indices = np.where(predict_y == cluster_label)[0]
        true_labels_in_cluster = y[cluster_indices]
        
        # 找到众数（如果有多个，选择第一个）
        mode_label = np.argmax(np.bincount(true_labels_in_cluster))
        
        # 将聚类标签映射到众数
        label_mapping[cluster_label] = mode_label

    return label_mapping

def map_labels(predict_y, label_mapping):
    """
    使用映射关系字典将聚类标签映射到真实标签
    
    Parameters:
        predict_y (array-like): 聚类算法的预测标签
        label_mapping (dict): 映射关系字典
    
    Returns:
        array-like: 映射后的标签
    """
    mapped_labels = np.array([label_mapping[label] for label in predict_y])
    return mapped_labels

def calculate_accuracy_unsupervised(predict_y, y):
    """
    计算无监督聚类的准确率
    
    Parameters:
        predict_y (array-like): 聚类算法的预测标签
        y (array-like): 真实标签
    
    Returns:
        float: 准确率
    """
    # 获取映射关系
    label_mapping = map_cluster_labels(predict_y, y)

    # 映射聚类标签到真实标签
    mapped_predict_y = map_labels(predict_y, label_mapping)

    # 计算准确率
    accuracy = accuracy_score(y, mapped_predict_y)

    return accuracy





   
        


      
        
scq_datasets = [   
    'Klein',
    'Kumar',
    'KumarTCC',   
]





# n_pcs_list=[10,15]

n_pcs_list=[10]
n_top_genes_list=[3000]



for dataset in scq_datasets:
        
    
    [X,Y]=LoadSingleCellSequencing.LoadData(dataset)     
    
    print(dataset)
    nK=len(set(Y))
    print('K=',nK)
     
    Log.Record('\n------------',dataset,'-----\n')
    
    
    bFindBestClustering=False
    
    
    for n_pcs in n_pcs_list:        
        for n_top_genes in n_top_genes_list:   
            
            if bFindBestClustering:
                break
            
            Log.Record('n_pcs=',n_pcs, 'n_top_genes=',n_top_genes)             
           
                
            adata = sc.read("data/danxibao_csv/"+dataset+".csv").transpose()                
            
           
            ProcessData(adata,n_top_genes=n_top_genes, n_pcs=n_pcs)
            
            
            scq_clustering=SCQ_Clustering(  )
            
            # scq_clustering.Set_k_range(k_range= list(range( max(2,nK-3),nK+4)) )
            
            
            record=scq_clustering.Optimal_clustering_using_PCA_data(adata, n_pcs=n_pcs)            
            
            
            
            reliableSubsets=record[2]
            
            
            PrecisionOfSubsets(reliableSubsets,Y)
            
            n_clusters=len(reliableSubsets)    
            
           
            Log.Record('nK=', nK, 'n_clusters=', n_clusters)
        
            
            print(dataset+' realK= '+ str(nK)+' predK='+ str(n_clusters))
            
            cluster_result_best=scq_clustering.BestMethodInfo()
            
            cluster_result_best=np.array(cluster_result_best)
            
            
            # Log.Record(' len(cluster_result_best)= ', len(cluster_result_best), ' len(Y)=', len(Y))
            
            if len(cluster_result_best)==len(Y):    
                # 计算 ARI 和 NMI
                ari = adjusted_rand_score(Y, cluster_result_best)
                nmi = normalized_mutual_info_score(Y, cluster_result_best)
                
                
                print(dataset, ari, nmi)
                
                Log.Record('ARI=', ari, 'NMI=',nmi)
                
         
            
        
 
            scq_clustering.Figure(dataset)
            
            
            #----------------------------------
            
            n_clusters=len(reliableSubsets)    
            
                      
            sample_in_reliableSet=set()
            for i in range(n_clusters):                 
                sample_in_reliableSet=sample_in_reliableSet.union(reliableSubsets[i])
                
                
            all_samples = set(range(len(Y)))   
            
            sample_not_in_reliableSet=all_samples-sample_in_reliableSet
            
            
            sample_in_reliableSet=list(sample_in_reliableSet)
            
            sample_not_in_reliableSet=list(sample_not_in_reliableSet)
            
            
            # 获取映射关系
            label_mapping = map_cluster_labels(cluster_result_best, Y)
            
            # 映射聚类标签到真实标签
            mapped_predict_y = map_labels(cluster_result_best, label_mapping)
            
            
            # 使用accuracy_score计算准确率
            accuracy = accuracy_score(mapped_predict_y[sample_in_reliableSet], Y[sample_in_reliableSet])
            
            accuracy1 = accuracy_score(mapped_predict_y[sample_not_in_reliableSet], Y[sample_not_in_reliableSet])
            
            accuracy2 = accuracy_score(mapped_predict_y, Y)
            
            print('sample_in_reliableSet ', len(sample_in_reliableSet),' accuracy=',accuracy,' sample_not_in_reliableSet ',len(sample_not_in_reliableSet), 'accuracy=',accuracy1, accuracy2)
            
            #---------------------------------------------
            
           
        
            # 运行Louvain聚类
            # 'louvain with default parameters':            
            sc.pp.neighbors(adata, n_pcs=n_pcs,use_rep='X_pca') 
            sc.tl.louvain(adata)          
            
            clusters_louvain=adata.obs['louvain'].astype(int)
            
            ari = adjusted_rand_score(Y, clusters_louvain)
            nmi = normalized_mutual_info_score(Y, clusters_louvain)
            Log.Record('louvain with default parameters', ' ARI=', ari, 'NMI=',nmi)
            
                
            # 'leiden with default parameters':    
            sc.pp.neighbors(adata, n_pcs=n_pcs,use_rep='X_pca') 
            sc.tl.leiden(adata)        
            clusters_leiden=adata.obs['leiden'].astype(int)
            
            ari = adjusted_rand_score(Y, clusters_leiden)
            nmi = normalized_mutual_info_score(Y, clusters_leiden)
            Log.Record('leiden with default parameters', ' ARI=', ari, 'NMI=',nmi)
               
                
          
                
                       
                
    
    



    
    







