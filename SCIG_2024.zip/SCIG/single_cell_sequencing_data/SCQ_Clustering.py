# -*- coding: utf-8 -*-
"""
Created on Mon Oct  9 08:54:13 2023

@author: Xiaojun Ding
"""


import numpy as np


import scanpy as sc



import matplotlib.pyplot as plt


import os 



from sklearn.cluster import KMeans



from OPCluster import OPClustering
    



class SCQ_Clustering:
    
    
    
    def SCQ_Clustering(self):
        
        self.k_range=list(range(2,10)) 
        
        
    
    
    def Set_k_range(self, k_range):       
        
        self.k_range=k_range
      
            
    
    
    
    def Bind_SC_data(self,adata, n_pcs=10):   
        
        self.adata=adata
        
        self.n_pcs=n_pcs
        
        pca_coordinates = adata.obsm['X_pca']    
        
        opc0=OPClustering()
        
        self.XX=opc0.GenerateXX(pca_coordinates, n=9, noiseRatio=0.1)   
        
        
        
        
        
    def ReliableInformation(self,  clustering_method='louvain', metric='cosine', resolution=0.1, n_clusters=2):           #  clustering_method='louvain','leiden',  metric='cosine', 'correlation' ,    
               
       
    
        adata=self.adata
        
        n_pcs=self.n_pcs
        
        XX=self.XX
        
        results=[]
        
        for i in range(10):   
            adata.obsm['X_pca']=XX[i]     
            
            # 运行Louvain聚类
            if clustering_method=='louvain':            
                sc.pp.neighbors(adata, n_pcs=n_pcs,use_rep='X_pca', metric=metric) 
                sc.tl.louvain(adata, resolution=resolution)          
                
            if clustering_method=='leiden':
                sc.pp.neighbors(adata, n_pcs=n_pcs,use_rep='X_pca', metric=metric) 
                sc.tl.leiden(adata, resolution=resolution)  
                                  
                
            if clustering_method=='kmeans':                      
                kmeans = KMeans(n_clusters=n_clusters )  # 设置簇数为您需要的值
                kmeans.fit(adata.obsm['X_pca'])
                adata.obs['kmeans'] = kmeans.labels_
                
                
            
            clustering_result=adata.obs[clustering_method].astype(int)  
            
            results.append(clustering_result)          
        
       
        opc=OPClustering()
        
        kernelSets=opc.Kernel(results,len(XX)-1)            
                    
        information=opc.Information(kernelSets,XX[0].shape[0])
        
        
        
        if (clustering_method=='kmeans') :            
            
            print('n_clusters=', n_clusters,  'information=',information)    
            
            return [information, clustering_method, kernelSets, n_clusters]
        
        else:          
            if not(kernelSets is None):
                print('resolution=',resolution,  '#cluster=', len(kernelSets),  'information=',information)
            else:                
                print('resolution=',resolution,  '#cluster=', 1,  'information=',information)
                
            return [information, clustering_method, kernelSets, metric, resolution]
            
    
    
   
    def TryParameters(self, clustering_method='louvain', metric='cosine'):           #  clustering_method='louvain','leiden',  metric='cosine', 'correlation' ,
    
       
        print(' ')
        
        
        records=[]
        
        if (clustering_method=='kmeans') : 
            
            print(clustering_method)
            
            for n_clusters in self.k_range:           
                
                records.append(self.ReliableInformation(clustering_method=clustering_method,n_clusters=n_clusters )  )            
            
        else:            
            
            print(clustering_method, 'metric=', metric)               
            
            for k in range(1,16):
                
                resolution=round(k*0.1,1)
                
                records.append(self.ReliableInformation(clustering_method=clustering_method, metric=metric, resolution=resolution )  )
            
        return records
            
      
        

    def Optimal_clustering_using_PCA_data(self, adata, n_pcs=10):       
        
        # 获取PCA变换后的坐标矩阵
        
        self.Bind_SC_data(adata, n_pcs)
        
        
        records=[]
        
        records.extend( self.TryParameters( clustering_method='louvain',metric='euclidean') )        
        
        records.extend( self.TryParameters( clustering_method='louvain',metric='correlation') )
        
        records.extend( self.TryParameters( clustering_method='leiden',metric='euclidean') )        
        
        records.extend( self.TryParameters( clustering_method='leiden',metric='correlation') )
        
        
        
        # records.extend( self.TryParameters( clustering_method='kmeans') )      


        self.records=records           
        
               
        informations=[]

        for i in range(len(records)):    
            informations.append(records[i][0])            
       
        
        self.best_method_idx=np.argmin(informations)    
        
        
        self.BestMethodInfo()        
        
        return records[self.best_method_idx]
    
        
    
    #-----------------------for visualization ---------------
    
    
    def BestMethodInfo(self):
        
        
        records=self.records
        idx=self.best_method_idx
        
        
        print('\n recommend clustering')
        
        clustering_method=records[idx][1]
        
        
        if  (clustering_method=='kmeans'): 
            print(records[idx][1],'n_clusters=',records[idx][3], 'information=',records[idx][0])
        else:
            print(records[idx][1],'metric=',records[idx][3],'resolution=',records[idx][4], 'information=',records[idx][0])
        
        
        #-----------------visualize--------------------             
       
       
        if  (clustering_method=='kmeans'): 
            return self.UMAP_for_specified_clustering(clustering_method=clustering_method,n_clusters=records[idx][3],bUMAP=True)        
        else:
            return self.UMAP_for_specified_clustering(clustering_method=clustering_method,metric=records[idx][3],resolution=records[idx][4],bUMAP=True)
        #-------------------------------------
        
        
        
 
    def UMAP_for_specified_clustering(self, clustering_method='louvain', metric='cosine', resolution=0.1, n_clusters=2, bUMAP=True):
    
                                 
    
        adata=self.adata
        
        n_pcs=self.n_pcs
        
        adata.obsm['X_pca']=self.XX[0]   
    
        # 运行Louvain聚类
        if clustering_method=='louvain':            
            sc.pp.neighbors(adata, n_pcs=n_pcs,use_rep='X_pca', metric=metric) 
            sc.tl.louvain(adata, resolution=resolution)          
            
        if clustering_method=='leiden':
            sc.pp.neighbors(adata, n_pcs=n_pcs,use_rep='X_pca', metric=metric) 
            sc.tl.leiden(adata, resolution=resolution)               
           
            
        if clustering_method=='kmeans':                      
            kmeans = KMeans(n_clusters=n_clusters )  # 设置簇数为您需要的值
            kmeans.fit(adata.obsm['X_pca'])
            adata.obs['kmeans'] = kmeans.labels_
            
                   
            
        # if bUMAP:            
        #     # # 运行umap降维
        #     sc.tl.umap(adata)    
        #     sc.pl.umap(adata, color=clustering_method)
            
        #     # # # 运行t-SNE降维
        #     # sc.tl.tsne(adata)           
        #     # sc.pl.tsne(adata, color=clustering_method)   
        
        
        
        return adata.obs[clustering_method].astype(int)
    
    
    def UMAP_for_real_label(self, Y):   
        
        adata=self.adata

        adata.obs['real_label']=Y 
        
        sc.tl.umap(adata)    
        sc.pl.umap(adata, color='real_label')
        
        
    
    #-----------------------for visualization ---------------
    
    def ExtractForFigure(self, clustering_method, metric=''):        
        
        records=self.records     
        
        Y=[]
        
        if clustering_method=='kmeans':
            
            label=clustering_method
            
            for i in range(len(records)):            
                if (records[i][1]==clustering_method):
                    Y.append(records[i][0])
        else:
            
            label=clustering_method+'_'+metric
            
            for i in range(len(records)):            
                if (records[i][1]==clustering_method) and (records[i][3]==metric):
                    Y.append(records[i][0])
                    
                    
        return [label,np.array(Y)]
        
       
        
        
        
        
    
    def Figure(self, caption=''):    
    
        
            plt.cla()
            
            _fontsize=12
            plt.xticks(fontsize=_fontsize)
            plt.yticks(fontsize=_fontsize)     
            plt.legend(fontsize=_fontsize)
    
            colors = ['r','g', 'b','c', 'y']    
            
            linestyles=['--','-',':','-.']
                
            plt.rcParams['figure.figsize'] = (8.0, 4.0) # 设置figure_size尺寸
            
            plt.figure()
            
            plt.xticks(np.arange(0, 2, 0.1))             
            
            X=np.arange(0.1, 1.6, 0.1)            
          
            methods=[['louvain','euclidean'],['louvain','correlation'],['leiden','euclidean'],['leiden','correlation']]
            
            for i in range(4):
            
                [label,Y]=self.ExtractForFigure(clustering_method=methods[i][0],metric=methods[i][1])
                
                plt.plot(X,Y,label=label,color=colors[i%len(colors)],linestyle=linestyles[i%len(linestyles)])   
                
          
            
            plt.xlabel('resolution',fontsize=_fontsize,labelpad=-30)
            plt.ylabel('information',fontsize=_fontsize)
                       
            
            plt.rcParams['savefig.dpi'] = 100 #图片像素
            plt.rcParams['figure.dpi'] = 300 #分辨率
            
            
            
            plt.suptitle(caption, fontsize=12, color='black')
            
            
            leg = plt.legend(loc = 'best',fontsize=_fontsize)
            leg.get_frame().set_alpha(0.2)
            
            
            
            plt.show()
            
            
            savePath=caption+'_louvain_leiden.jpg'    
                
            plt.savefig(savePath, dpi=300)
            
            
            # # 关闭图形窗口（可选）
            # plt.close()
            
            
            
            
    def Figure_KMeans(self, caption=''):    
    
        
        plt.cla()
        
        _fontsize=14
        plt.xticks(fontsize=_fontsize)
        plt.yticks(fontsize=_fontsize)     
        plt.legend(fontsize=_fontsize)

        colors = ['r','g', 'b','c', 'y']    
        
        linestyles=['--','-',':','-.']
            
        plt.rcParams['figure.figsize'] = (8.0, 4.0) # 设置figure_size尺寸
        
        plt.figure()
        
        plt.xticks(self.k_range) 
       
        X=self.k_range
        
        [label,Y]=self.ExtractForFigure(clustering_method='kmeans')
        
        i=0
        
        plt.plot(X,Y,label=label,color=colors[i%len(colors)],linestyle=linestyles[i%len(linestyles)])   
            
      
        
        plt.xlabel('k',fontsize=_fontsize)
        plt.ylabel('information',fontsize=_fontsize)
                   
        
        plt.rcParams['savefig.dpi'] = 100 #图片像素
        plt.rcParams['figure.dpi'] = 300 #分辨率
        
        plt.suptitle(caption, fontsize=12, color='black')
        
        
        leg = plt.legend(loc = 'best',fontsize=_fontsize)
        leg.get_frame().set_alpha(0.2)
       
        plt.show()
        
        savePath=caption+'_kmeans.jpg'    
            
        plt.savefig(savePath, dpi=300)
        
      
   
       
        
       


    











    
    
    



    
    







