Environment:   OS: win10,   python 3.11.5，   package: scanpy


step 1.  Please unzip the files Klein.rar, Kumar.rar, and KumarTcc.rar in the 'danxibao_csv' directory. Due to the file size limit of 25MB, these datasets have been uploaded individually.



Step 2.  Please click on run.bat to replicate the experiment described in the paper, which utilizes the Louvain and Leiden clustering algorithms for single-cell sequencing datasets.