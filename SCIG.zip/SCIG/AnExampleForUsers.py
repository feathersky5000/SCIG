# -*- coding: utf-8 -*-
"""
Created on Tue May 25 16:19:39 2021

@author: Xiaojun Ding
"""


from OPCluster import *

from OPClusterTest import *

#------------------------ An example that users can use their data and clustering algorithm-------------





# Users can add or remove their clustering methods or parameters
# The clustering methods should provide a function fit(X,k), where X is the input, k is the number of clusters. The function should return a clustering result just like the following:

#--------------------------------------------------
# An example of clustering method by user

def fit_by_user(X,k):    
    kmeans = KMeans(n_clusters=k,init='random',n_init=10).fit(X)         
    return kmeans.labels_
#--------------------------------------------------
    


def AnExampleForUsers(X,minK=2,maxK=15,FigureOff=False,noiseRatio=0.1,noisingMethod='gaussian'):
    
       
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
   
      
        
    op.AddClusteringMethod('KMeans (user)',fit_by_user)        # the clustering method written by user  

    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)

    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        

        
    
    #--------------method type=2-----------------
    op.methods2={}
    
    op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
    
    op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
##        
           
    

    
    op.OpCluster(X,Y=None,minK=minK,maxK=maxK,savePath='result\\',noiseRatio=noiseRatio,noisingMethod=noisingMethod)
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数

#-----------------------------------------------
    
    




[X,Y] = LoadData('Iris')  # Load your Data.
 
AnExampleForUsers(X,minK=2,maxK=15)  # Find the best K and clustering method.
