# -*- coding: utf-8 -*-
"""
Created on Mon Jun 10 15:08:58 2019

@author:  Xiaojun Ding
 

"""



import warnings

warnings.filterwarnings('ignore')



import numpy as np
import pandas as pd

from sklearn import metrics



#from Bio.Cluster import kcluster          # pip install biopython

from sklearn.preprocessing import LabelEncoder

from sklearn import datasets



from sklearn.datasets import make_blobs



import scipy.io as scio
    
from sklearn import cluster


from scipy.io import arff



from sklearn import preprocessing


# Imports
from sklearn.datasets import fetch_olivetti_faces


import os 

import random
import sys



from OPCluster import *
    
    
    
    
    
#-------------------------------------------
        

def score_and_rank(df, idx):
    
    scores=df.iloc[:,idx]
    
    score=scores[0]
    
    scores[0]+=0.001    # in case of the instability of sorting
    
    sortedIdx=np.argsort(-scores) 
    
    for k in range(len(scores)):
        if sortedIdx[k]==0:
            return [score,k+1]
        
    return [score,1]
    
    
        
    
def StatisticalAnalysis(dataset,start=0,end=100,postfix=''):
    
        
    score_rank_ARI=np.array([0,0])
    score_rank_NMI=np.array([0,0])
    
    avg_stability=0
    
    avg_stabilityCount=0
    
    nMethods=1
    
    count=0
    
    hits=np.array([0,0])
    
    noFileCount=0
    
    for i in range(start,end,1):               
                
        filename=dataset+"/result"+str(i)+"_all.csv"      
     
        
        if os.path.isfile(filename)==False:   
            noFileCount+=1           
       
            continue
        
        if noFileCount>30:
            break
        
        df=pd.read_csv(filename,sep=',')  
        
        if len(df)<1:
            continue
        
        #----------------------------------  
        
        nMethods=df.shape[0]
       
        score_rank_ARI=score_rank_ARI+np.array(score_and_rank(df,4))
        score_rank_NMI=score_rank_NMI+np.array(score_and_rank(df,3))
        
#        print('stability=',float(df.iloc[:,9][0]))
        
        if 'stabilityScore' in df.columns:      
            avg_stability+=float(df['stabilityScore'][0])
            avg_stabilityCount+=1
        
        count+=1
        
        #--------------------------------
        realK=df['realK'][0] 
        ks=df['k'][0:3]
    
        if ks[0]==realK:
            hits[0]+=1
        
        
        if (ks[0]==realK) or (ks[1]==realK) or (ks[2]==realK):
            hits[1]+=1
        
    #-------------------------------------
    
    if count>0:
        
        score_rank_ARI=np.round(score_rank_ARI/count,2)
        score_rank_NMI=np.round(score_rank_NMI/count,2)
        avg_stability=np.round(avg_stability/avg_stabilityCount,2)
        
        content='dataset,rank_ARI,avg_ARI,rank_NMI,avg_NMI,nMethods,top1HitK,top3HitK,stability,#tests\n'
        
        content+="{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}".format(dataset,np.round(score_rank_ARI[1],1),score_rank_ARI[0],np.round(score_rank_NMI[1],1),score_rank_NMI[0],nMethods,int(hits[0]*100/count),int(hits[1]*100/count),avg_stability,count)
        
        print(content)
        
        fd = os.open(dataset+'/statistic_'+postfix+'.csv',os.O_RDWR|os.O_CREAT)
    
        os.write(fd,str.encode(content))
    
        os.close(fd)
    



   
    
def CombineStatisticalAnalysis( rootdir = './',postfix=''):
    
#    rootdir = './'   # 需要遍历的文件夹，这里设定为当前文件夹

    dataframes=[]
    # 如果此循环在迭代第一次时break出，则其效果和上面的相同
    for root, dirs, files in os.walk(rootdir):    # 当前路径、子文件夹名称、文件列表
#        for filename in files:
#            print (filename)
        for dirname in dirs:            
            
            resultFile=dirname+'/statistic_'+postfix+'.csv'
            
            if os.path.isfile(resultFile)==True: 
                try:
                    df=pd.read_csv(resultFile,sep=',')
                    
                    print(dirname, ' done')
                except Exception as e:
                    print(e)
                    continue
                 
                dataframes.append(df)
        
    combinedResults = pd.concat(dataframes)
   
    combinedResults.to_csv('combinedStatisticlResults.csv', sep=',', encoding='utf-8')

















#-------------------------------for test ----------------------------------
    
   
    
    
def CirclePoints(x0,y0,r,n):
  
    X=np.zeros((n,2))
#    X[:,0]=np.random.uniform(low=x0-r,high=x0+r,size=n)
    
    
    angle=np.arange(0,360,360/n)        
        
    X[:,0]=x0+r*np.cos(angle)  
    
    X[:,1]=x0+r*np.sin(angle)  

           
    return X


#-----------------------------
    



#
#
#def load_mnist(path, kind='train'):
#    """Load MNIST data from `path`"""
##    labels_path = os.path.join(path,
##                               '%s-labels-idx1-ubyte'
##                               % kind)
##    images_path = os.path.join(path,
##                               '%s-images-idx3-ubyte'
##                               % kind)
#    
#    labels_path = os.path.join(path,
#                               '%s-labels.idx1-ubyte'
#                               % kind)
#    images_path = os.path.join(path,
#                               '%s-images.idx3-ubyte'
#                               % kind)
#    
#    
#    with open(labels_path, 'rb') as lbpath:
#        magic, n = struct.unpack('>II',
#                                 lbpath.read(8))
#        labels = np.fromfile(lbpath,
#                             dtype=np.uint8)
#
#    with open(images_path, 'rb') as imgpath:
#        magic, num, rows, cols = struct.unpack('>IIII',
#                                               imgpath.read(16))
#        images = np.fromfile(imgpath,
#                             dtype=np.uint8).reshape(len(labels), 784)
#
#    return images, labels



def LoadData(sample_str):
        
    X=Y=None
    
   
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    extension=os.path.splitext(sample_str)[-1] 
    
 
    
    if datasetName == 'k5':        
        X, Y = make_blobs(n_samples=100, n_features=2, centers=5,random_state=3)
        
    if datasetName == 'k10':        
        X, Y = make_blobs(n_samples=600, n_features=10, centers=10,random_state=3)
        
    if datasetName == 'k15':        
        X, Y = make_blobs(n_samples=600, n_features=15, centers=15,random_state=3)
    
    if datasetName == 'dualCircles':
       
        n=100
        X0=CirclePoints(5,5,5,n)
        Y0=np.zeros(n,dtype='int')
        
        X1=CirclePoints(5,5,2.5,n)
        Y1=np.ones(n,dtype='int')
#      
        
        X=np.vstack((X0,X1))       
        Y=np.hstack((Y0,Y1))   
#       
        
    if datasetName == 'pc3':      
        
        n=50
        X0=np.zeros((n,2))
        X0[:,0]=np.arange(0,10,0.2)
        X0[:,1]=1*X0[:,0]
        Y0=np.ones(n,dtype='int')*0
        
      
        X1=np.zeros((n,2))
        X1[:,0]=np.arange(0,10,0.2)
        X1[:,1]=2*X1[:,0]
        Y1=np.ones(n,dtype='int')*1
        
        X2=np.zeros((n,2))
        X2[:,0]=np.arange(0,10,0.2)
        X2[:,1]=-1*X2[:,0]
        Y2=np.ones(n,dtype='int')*2
        
        X=np.vstack((X0,X1,X2))       
        Y=np.hstack((Y0,Y1,Y2))   
        
        
    
    if datasetName == 'Iris':
        sample = datasets.load_iris()
        X = sample.data
        Y = sample.target
        
    if datasetName == 'Wine':
        sample = datasets.load_wine()
        X = sample.data
        Y = sample.target       
        
    if datasetName == 'Car Evaluation':
        df = pd.read_csv('dataset/car.csv')
        df2=np.array(df)        
        X=df2[:,1:7]
        Y=df2[:,7]
        
    if datasetName == 'Digits':
        sample = datasets.load_digits()
        X = sample.data
        Y = sample.target
    
    if extension == '.mat':        
#        
        path='dataset/'   
        data = scio.loadmat(path+sample_str)        
        X=data['data']
        Y=data['label']
        Y=Y.reshape(-1,)
        Y=np.array(Y,dtype=int)
        
    if (datasetName == 'winequality-red') or (datasetName == 'winequality-white'):
                
        columns = ["facidity", "vacidity", "citric", "sugar", "chlorides", "fsulfur", 
                       "tsulfur", "density", "pH", "sulphates", "alcohol", "quality"]
        
#        "http://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"
#        "http://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-white.csv"
        
        wines=pd.read_csv("http://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/"+sample_str+".csv",
                             names=columns, sep=";", skiprows=1)
        
   
       
        wines=np.array(wines,dtype=float)
        X=wines[:,0:11]
        Y=wines[:,11]
        Y=np.array(Y,dtype=int)     
    
    if extension=='.arff':  
        
        path='dataset/ARFF/'     
        
        data,meta = arff.loadarff(path+sample_str)
        
        df = pd.DataFrame(data)

        try:    
            i=0
            names=meta.names()
            for t in meta.types():
                if t=='nominal':
                    df[names[i]]=LabelEncoder().fit_transform(df[names[i]])
                i+=1
        except Exception as e:            
            print(sample_str, 'does not include the description of attrnames or _attributes',e)
           
        classStr=''
        
        if 'class' in df.columns:
            classStr='class'
            
        if 'CLASS' in df.columns:
            classStr='CLASS'
        
        if classStr!='':
            
            cX=df.loc[:,df.columns != classStr]
            cY=df[classStr]  
            
            X=np.array(cX)
            Y=np.array(cY,dtype=int)            
        
        
    if sample_str=='TCGA-PANCAN-HiSeq':
        
               
        df_x = pd.read_csv('dataset/TCGA-PANCAN-HiSeq/data.csv')
        
        df_y = pd.read_csv('dataset/TCGA-PANCAN-HiSeq/labels.csv')        
       
        cX=df_x.loc[:,df_x.columns !=df_x.columns[0]]           
        
        cY=preprocessing.LabelEncoder().fit_transform(df_y['Class'])
        
        X=np.array(cX)
        Y=np.array(cY,dtype=int)       
        
        
    if(datasetName == 'olivetti_faces'):

        olivetti_faces_x_file="dataset/olivetti/olivetti_X.csv"
        olivetti_faces_y_file="dataset/olivetti/olivetti_Y.csv"
        
        if os.path.isfile(olivetti_faces_y_file)==False:            
            olivetti = fetch_olivetti_faces()
            x = olivetti.images
            y = olivetti.target            
            
            # Print info on shapes and reshape where necessary
            print("Original x shape:", x.shape)
            X = x.reshape((400, 4096))
            print("New x shape:", X.shape)
            print("y shape", y.shape)
            
            # Save the numpy arrays
            Y=y
            np.savetxt(olivetti_faces_x_file, X, delimiter = ",")
            np.savetxt(olivetti_faces_y_file, Y, delimiter = ",", fmt = '%d')
            
            print("\nDownloading and reshaping done!")
        else:            
            
            X = np.loadtxt(olivetti_faces_x_file, delimiter = ",")                        
        
            Y = np.loadtxt(olivetti_faces_y_file, delimiter = ",")
            Y=Y.astype(np.int)
          
            X=X[0:100,:]
            Y=Y[0:100,]
    
#    if(datasetName == 'MNIST'): 
#        
##        train_images = mnist.train_images()
##        train_labels = mnist.train_labels()
#        
#        [train_images,train_labels]=load_mnist('dataset\MNIST')
#        
#
#        XX=np.reshape(train_images,(60000,28*28))
#        
#        count=200
#        
#        X=np.array(XX[0:count,:])
#        
#        Y=np.array(train_labels[0:count,],int)


    if (datasetName == 'Levine_13dim') or  (datasetName =='Levine_13dim_notransform'):
      
#        datasetName = 'Levine_13dim'
        df = pd.read_csv('dataset/FlowRepository/'+datasetName+'.csv')
        df2=np.array(df)     
        nF=df2.shape[1]-1
        X=df2[:,0:nF]
        Y=np.array(df2[:,nF],int)

    

   
    if (sample_str.endswith('.all_features.txt')) or  (sample_str.endswith('.seled_features.txt')):
        
       
        file=''
        
        if (sample_str.endswith('.all_features.txt')):
            file='dataset/dataset1_all_features/'+sample_str
        else:
            file='dataset/dataset2_chosen_feaures/'+sample_str
        
        df = pd.read_csv(file,'\t')

        df2=np.array(df)
        
        nF=df2.shape[1]-1
        
        X=df2[:,1:nF]     
        
        X=np.array(X,float)
        
        Y=np.array(df2[:,nF],int)
        
        

    if not Y is None:
        print('nX=',X.shape[0],' nF=',X.shape[1],' k=',len(set(Y)))     
        print('cluster size=',np.bincount(Y))

                
    return [X,Y]



#---------------------------------------------------
    



def TestDataset(dataset,minK=2,maxK=15,FigureOff=False,noiseRatio=0.1,noisingMethod='gaussian'):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        

        
    
    #--------------method type=2-----------------
    op.methods2={}
    
    op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
    
    op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_0.4',cluster.DBSCAN(eps = 0.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.6',cluster.DBSCAN(eps = 0.6).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.0',cluster.DBSCAN(eps = 1.0).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_1.2',cluster.DBSCAN(eps = 1.2).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.4',cluster.DBSCAN(eps = 1.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
##        
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0],noiseRatio=noiseRatio,noisingMethod=noisingMethod)
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数

#-----------------------------------------------
    
    
    








def Analysis():    

    filePath = 'dataset/ARFF/'
    arff_datasets=os.listdir(filePath)
    
    datasets=['k5','k10','k15','dualCircles','gaussian.mat','Iris','Wine','Car Evaluation','winequality-red', 'olivetti_faces','TCGA-PANCAN-HiSeq','MNIST','Levine_13dim','Levine_13dim_notransform']  #the dataset contains 20000 features and runs slowly
    
    datasets.extend(arff_datasets)
    
    
    for i in range(len(datasets)):
            
        dataset=datasets[i]
        
        StatisticalAnalysis(os.path.splitext(dataset)[0])
            
    CombineStatisticalAnalysis()


#---------------------------------

def TestAllDatasets():    
    
    filePath = 'dataset/ARFF/'
    arff_datasets=os.listdir(filePath)
    
    datasets=['k5','k10','k15','dualCircles','gaussian.mat','Iris','Wine','Car Evaluation','winequality-red', 'TCGA-PANCAN-HiSeq','olivetti_faces','Levine_13dim','Levine_13dim_notransform']  #the dataset contains 20000 features and runs slowly

    
    datasets.extend(arff_datasets)
    
    
    start=random.randint(1,len(datasets))
    
    #start=0
    
    for k in range(5):
        
        for i in range(len(datasets)):
            
            dataset=datasets[(i+start)%len(datasets)]
                       
            try:
                TestDataset(dataset,FigureOff=True)
            
            except Exception as e:
                
                print(dataset,e)
                continue
            
             
#----------------------------------------------------------------




def TestATCG(dataset='TCGA-PANCAN-HiSeq',minK=2,maxK=15,FigureOff=False):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        
    
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0])
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数



#-----------------------------------------------
    
    

def TestFlow(dataset,minK=2,maxK=15,FigureOff=False):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
     
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0])
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数



#-----------------------------------------------
    
            
#Analysis()
#
#TestAllDatasets()
                
#TestDataset('TCGA-PANCAN-HiSeq')
#TestDataset('banana.arff')
                
def  MultipleClusteringWithNoise(dataset='dualCircles',k=2):
          
    [X,Y]=LoadData(dataset)
    
    op=OPClustering()
    #
    op.FigureOff=False
    
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
   
        
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
    #    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
    #    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
    #    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
    #    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
    #    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
  
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
    
    
                
    op.MultipleClusteringWithNoise(X,k)
    
    rscImages=[]
    for clusteringName,clusteringMethod in op.methods.items():   
        
        rscImages.append(clusteringName+'.jpg')
        
#    CombineImages2(path='',rscImages=rscImages,option='v') #调用函数          
#          
#
#MultipleClusteringWithNoise(dataset='dualCircles',k=3)   
#
##------------------------------

def olivetti_faces_science():
    oY=np.zeros((100,))    
    
    for i in range(100):
        oY[i]=int(i/10)

    Y=np.zeros((100,))  
    
    Y[10]=Y[12]=Y[14]=Y[16]=Y[17]=Y[19]=1
    Y[30]=Y[32]=Y[37]=2
    Y[40]=Y[43]=Y[46]=3
    Y[50]=Y[51]=Y[52]=4
    Y[53]=Y[54]=Y[55]=Y[56]=Y[59]=5
    Y[60]=Y[61]=Y[62]=Y[63]=Y[64]=Y[65]=Y[66]=Y[67]=Y[68]=Y[69]=6
    Y[72]=Y[74]=Y[75]=Y[77]=7
    Y[80]=Y[81]=Y[82]=8
    Y[91]=Y[94]=Y[95]=Y[97]=9
    
    info={}
    info['NMI']=round(metrics.normalized_mutual_info_score(oY,Y),2)
    info['ARI']=round(metrics.adjusted_rand_score(oY,Y),2)                           
    info['FMI']=round(metrics.fowlkes_mallows_score(oY,Y),2)
    info['homogeneity']=round(metrics.homogeneity_score(oY,Y),2) 
    info['completeness']=round(metrics.completeness_score(oY,Y),2) 
    info['v_measure']=round(metrics.v_measure_score(oY,Y),2)    
  
  
    






def main(argv):   
    print('running.........')
    
    if len(sys.argv)>1:
        if str(sys.argv[1])=='Analysis':
            print('Analysis')
            Analysis()
            
        elif str(argv[1])=='TestAllDatasets':           
            TestAllDatasets()
            
        elif str(argv[1])=='Test':    
            if len(sys.argv)==5:
                TestDataset(argv[2],int(argv[3]),int(argv[4]))
            elif len(sys.argv)==8:
                TestDataset(dataset=argv[2],minK=int(argv[3]),maxK=int(argv[4]),FigureOff=(argv[5]=='True'), noiseRatio=float(argv[6]),noisingMethod=argv[7])
            else:
                TestDataset(argv[2])
        elif str(argv[1])=='TestATCG':
            TestATCG()  
            
        elif str(argv[1])=='TestFlow':
            TestFlow(argv[2])  
        elif str(argv[1])=='StatisticalAnalysis':
            StatisticalAnalysis(argv[2],start=int(argv[3]),end=int(argv[4])) 


if __name__ == '__main__':
    main(sys.argv)






#TestDataset('disk-3000n.arff')

#
#MultipleClusteringWithNoise(dataset='disk-3000n.arff',k=4)



#StatisticalAnalysis('cpu')


#dataset='cpu'
#  
#filename=dataset+"/result"+str(i)+"_all.csv"      
# 
#
#
#df=pd.read_csv(filename,sep=',')  
#
#print(len(df))
#
#avg_stability=float( df.iloc[:,9][0])
        



