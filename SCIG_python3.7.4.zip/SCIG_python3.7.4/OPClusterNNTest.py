# -*- coding: utf-8 -*-
"""
Created on Mon Jun 10 15:08:58 2019

@author:  Xiaojun Ding
 

"""



from OPCluster import *


from OPClusterTest import *

#-----------------------------------------------------------------------------------




def TestDataset2(dataset,minK=2,maxK=15,FigureOff=False,noiseRatio=0.1,noisingMethod='gaussian'):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        

        
    
    #--------------method type=2-----------------
    op.methods2={}
    
    # op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    # op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    # op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    # op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
    
    # op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    # op.AddClusteringMethod('DBSCAN_0.4',cluster.DBSCAN(eps = 0.4).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_0.6',cluster.DBSCAN(eps = 0.6).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_1.0',cluster.DBSCAN(eps = 1.0).fit_predict, methodType=2)  
    # op.AddClusteringMethod('DBSCAN_1.2',cluster.DBSCAN(eps = 1.2).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_1.4',cluster.DBSCAN(eps = 1.4).fit_predict, methodType=2) 
    # op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
##        
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0],noiseRatio=noiseRatio,noisingMethod=noisingMethod)
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数

#-----------------------------------------------
    
    

    
def TestDataset111(sample_str,minK=2,maxK=12):
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    for i in range(10):
        TestDataset2(sample_str, minK, maxK,True, 0.25,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,0,10,'neighbour_0.25')
    
    for i in range(10):
        TestDataset2(sample_str, minK,maxK,True, 0.5,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,10,20,'neighbour_0.5')
    
    for i in range(10):
        TestDataset2(sample_str, minK, maxK,True, 1,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,20,30,'neighbour_1')
    
    for i in range(10):
        TestDataset2(sample_str, minK,maxK,True, 2,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,30,40,'neighbour_2')
    
    for i in range(10):
        TestDataset2(sample_str, minK, maxK,True, 3,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,40,50,'neighbour_3')
    
    for i in range(10):
        TestDataset2(sample_str, minK,maxK,True, 4,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,50,60,'neighbour_4')
    
    
# TestDataset111("Iris")    
# TestDataset111("ecoli.arff")    
# TestDataset111("k5") 
    
    
def TestDataset22(sample_str,minK=2,maxK=12):
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    for i in range(10):
        TestDataset2(sample_str, minK, maxK,True, 2,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,0,10,'neighbour_2')
    
    for i in range(10):
        TestDataset2(sample_str, minK,maxK,True, 3,'noisingByNeighbours')
        
    StatisticalAnalysis( datasetName,10,20,'neighbour_3')
    
 
    
testDatasets=['diamond9.arff','twenty.arff','k5','k10','k15','wdbc','ecoli.arff','banana.arff','2dnormals.arff','smile3.arff','disk-3000n.arff','R15.arff','balance-scale.arff']

def TestDataset222():
    
    for dataset in testDatasets:
        
        TestDataset22(dataset)
        
        
# TestDataset222()




def TestDataset3(dataset,minK=2,maxK=15,FigureOff=False,noiseRatio=0.1,noisingMethod='gaussian'):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        

        
    
    #--------------method type=2-----------------
    op.methods2={}
    
    op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
    
    op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_0.4',cluster.DBSCAN(eps = 0.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.6',cluster.DBSCAN(eps = 0.6).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.0',cluster.DBSCAN(eps = 1.0).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_1.2',cluster.DBSCAN(eps = 1.2).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.4',cluster.DBSCAN(eps = 1.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
        
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=os.path.splitext(dataset)[0],noiseRatio=noiseRatio,noisingMethod=noisingMethod)
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数

#-----------------------------------------------
    
    
    
    
    
def TestDataset33(sample_str,minK=2,maxK=15):
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    for i in range(10):
        TestDataset3(sample_str, minK, maxK,True, 2,'noisingByNeighbours')
        
    # StatisticalAnalysis( datasetName,0,10,'neighbour_2')
    

    
 
    
testDatasets=['diamond9.arff','twenty.arff','k5','k10','k15','wdbc','ecoli.arff','banana.arff','2dnormals.arff','smile3.arff','disk-3000n.arff','R15.arff','balance-scale.arff']

def TestDataset333():
    
    for dataset in testDatasets:
        
        TestDataset33(dataset)
        
        
# TestDataset333()




   
    
def CombineStatisticalAnalysis2( rootdir = './',rFile='statistic_neighbour_2.csv',combineResultFile='combinedStatisticlResults_N2.csv'):
    
#    rootdir = './'   # 需要遍历的文件夹，这里设定为当前文件夹

    dataframes=[]
    # 如果此循环在迭代第一次时break出，则其效果和上面的相同
    for root, dirs, files in os.walk(rootdir):    # 当前路径、子文件夹名称、文件列表
#        for filename in files:
#            print (filename)
        for dirname in dirs:            
            
            
            print(dirname)
             
            resultFile=dirname+'/'+rFile
            
            print(resultFile)
            
            if os.path.isfile(resultFile)==True: 
                try:
                    df=pd.read_csv(resultFile,sep=',')
                    
                    print(dirname, ' done')
                except Exception as e:
                    print(e)
                    continue
                 
                dataframes.append(df)
        
    combinedResults = pd.concat(dataframes)
   
    combinedResults.to_csv(combineResultFile, sep=',', encoding='utf-8')


# CombineStatisticalAnalysis2()

# CombineStatisticalAnalysis2(rootdir = './',rFile='statistic_neighbour_3.csv',combineResultFile='combinedStatisticlResults_N3.csv')



# TestDataset("Iris",2,10,True,0.5,noisingMethod='noisingByNeighbours')


# TestDataset("Car Evaluation",noisingMethod='category')
# TestDataset("4217_n2_region13007.nodes.g1.all_features.txt",2,12)


# TestDataset("3875_n2_region3563.nodes.g1.all_features.txt",2,12)


# TestDataset("3804_n2_region3168.nodes.g1.all_features.txt",2,12)



#----------------------------------







def TestDataset5(dataset,minK=2,maxK=15,root='',FigureOff=False,noisingMethod='combingGaussianAndNeighbours',ratio1=0.05, ratio2=1):
    
    [X,Y] = LoadData(dataset)  
    
    if X is None:
        return
    
    op=OPClustering()
    
    op.FigureOff=FigureOff
    
    op.PlotClusters(X,Y)
    
    
      
    op.ratio1=ratio1
    op.ratio2=ratio2
    
    
    
   
        
    op.AddClusteringMethod('KMeans',KMeansModel().fit)   
        
#    op.AddClusteringMethod('kcluster_e',kclusterModel(dist='e').fit)   
##    op.AddClusteringMethod('kcluster_c',kclusterModel(dist='c').fit)
##    op.AddClusteringMethod('kcluster_a',kclusterModel(dist='a').fit)
#    op.AddClusteringMethod('kcluster_u',kclusterModel(dist='u').fit)
    
    op.AddClusteringMethod('GaussianMixture',GaussianMixtureModel().fit)
    
    op.AddClusteringMethod('Agglomerative_euclidean_ward',AgglomerativClusteringModel(affinity='euclidean', linkage='ward').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_complete',AgglomerativClusteringModel(affinity='euclidean', linkage='complete').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_average',AgglomerativClusteringModel(affinity='euclidean', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_euclidean_single',AgglomerativClusteringModel(affinity='euclidean', linkage='single').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_complete',AgglomerativClusteringModel(affinity='cosine', linkage='complete').fit)
    op.AddClusteringMethod('Agglomerative_cos_avg',AgglomerativClusteringModel(affinity='cosine', linkage='average').fit)
#    op.AddClusteringMethod('Agglomerative_cosine_single',AgglomerativClusteringModel(affinity='cosine', linkage='single').fit)
#
#
#
#      
#    
#    
    op.AddClusteringMethod('Birch',BirchModel().fit)
    
    if X.shape[0]<2000:          # the spectral algorithm may go wrong when the number of samples is too large
    
        op.AddClusteringMethod('spectral gamma=1',SpectraClusteringModel(affinity='rbf',gamma=1).fit)
    #    op.AddClusteringMethod('spectral affinity=rbf gamma=2',SpectraClusteringModel(affinity='rbf',gamma=2).fit)
        op.AddClusteringMethod('spectral gamma=3',SpectraClusteringModel(affinity='rbf',gamma=3).fit)
        

        
    
    #--------------method type=2-----------------
    op.methods2={}
    
    op.AddClusteringMethod('MeanShift',MeanShiftModel().fit,methodType=2)  
    
    
    op.AddClusteringMethod('AffinityPropagation1',AffinityPropagationModel(damping=0.5,  preference=-30).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation2',AffinityPropagationModel(damping=0.5,  preference=-50).fit,methodType=2) 
    op.AddClusteringMethod('AffinityPropagation3',AffinityPropagationModel(damping=0.5,  preference=-70).fit,methodType=2) 
    
    op.AddClusteringMethod('DBSCAN_0.2',cluster.DBSCAN(eps = 0.2).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_0.4',cluster.DBSCAN(eps = 0.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.6',cluster.DBSCAN(eps = 0.6).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_0.8',cluster.DBSCAN(eps = 0.8).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.0',cluster.DBSCAN(eps = 1.0).fit_predict, methodType=2)  
    op.AddClusteringMethod('DBSCAN_1.2',cluster.DBSCAN(eps = 1.2).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.4',cluster.DBSCAN(eps = 1.4).fit_predict, methodType=2) 
    op.AddClusteringMethod('DBSCAN_1.6',cluster.DBSCAN(eps = 1.6).fit_predict, methodType=2) 
        
           
    
    nC=len(set(Y))
    
    if nC>maxK-5:
        minK=nC-5
        maxK=nC+5    
    
    op.OpCluster(X,Y,minK=minK,maxK=maxK,savePath=root+os.path.splitext(dataset)[0],noiseRatio=ratio1,noisingMethod=noisingMethod)
    
#    ShowResults(X,Y,range(2,maxK),dataset=dataset)
    
#    CombineResultsImage(filename=dataset) #调用函数


    

#-----------------------------------------------



    

s5dataSets=["2d-10c.arff","2d-4c-no4.arff","2dnormals.arff","banana.arff","chainlink.arff","complex8.arff","curves2.arff","Iris","Wine"]

def TestDataset55(sample_str,minK=2,maxK=15,root='',ratio1=0.05, ratio2=1):
    
    datasetName=os.path.splitext(sample_str)[0] 
    
    for i in range(10):
        TestDataset5(sample_str, minK, maxK,root,True, "combingGaussianAndNeighbours",ratio1,ratio2)
        
        

def TestDataset555(ratio1=0.05, ratio2=1):
    
    for sample_str in s5dataSets:
        
        root=str(ratio1)+"_"+str(ratio2)+"\\"
        
        TestDataset55(sample_str,2,15,root,ratio1,ratio2)
        
#    Analysis()
        

# TestDataset555(0.03,0.7)
        
# TestDataset555(0.03,1)

# TestDataset555(0.03,1.3)

# TestDataset555(0.05,0.7)
        
# TestDataset555(0.05,1)

# TestDataset555(0.05,1.3)

# TestDataset555(0.07,0.7)
        
# TestDataset555(0.07,1)

# TestDataset555(0.07,1.3)
