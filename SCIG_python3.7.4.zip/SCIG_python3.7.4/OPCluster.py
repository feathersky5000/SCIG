# -*- coding: utf-8 -*-
"""
Created on Mon Jun 10 15:08:58 2019

@author:  Xiaojun Ding


 

"""



import warnings

warnings.filterwarnings('ignore')



import numpy as np
import pandas as pd

from sklearn import metrics



#from Bio.Cluster import kcluster          # pip install biopython

from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import Birch 
from sklearn.cluster import SpectralClustering

from sklearn.mixture import GaussianMixture


from sklearn.cluster import KMeans

from sklearn import datasets


import matplotlib.pyplot as plt

from sklearn.datasets import make_blobs

from sklearn.cluster import MeanShift


from sklearn.cluster import AffinityPropagation

import scipy.io as scio
    
from sklearn import cluster


from scipy.io import arff



from sklearn import preprocessing


# Imports
from sklearn.datasets import fetch_olivetti_faces


import os 

import random
import sys




from collections import Counter


from scipy.spatial.distance import pdist
from scipy.spatial.distance import squareform



 

#-----------------------------------------------------------------------------------
    

# method: specifies how the center of a cluster is found: - method == 'a': arithmetic mean - method == 'm': median

# dist: specifies the distance function to be used: - dist == 'e': Euclidean distance - dist == 'b': City Block distance - 
# dist == 'c': Pearson correlation - dist == 'a': absolute value of the correlation - dist == 'u': uncentered correlation - 
# dist == 'x': absolute uncentered correlation - dist == 's': Spearman's rank correlation - dist == 'k': Kendall's tau

#class kclusterModel:    
#    
#    def __init__(self, method='a', dist='e'):
#        
#        self.method=method
#        self.dist=dist        
#        
#    def fit(self,X,k):
#        
#        clusterid, error, nfound = kcluster(X,nclusters=k,method=self.method, dist=self.dist)   # If you do not install the 'biopython' package, you can replace the 'kcluster' method with 'KMeans' 
#        return clusterid
#    
    
    
#----------------------------------------------------------

class KMeansModel:
#    def __init__(self):
        
        
    def fit(self,X,k):
        
        # The clustering reuslts are related to initial values.
        # If useing the 'k-means++’ parameter, for some datasets, the initial values are always the same and then we may always get the same local optima
        # If k-means can get the global optima, it will not affect our methods. But, if it always get the same local optima, our method will lose efficacy. So at here, we use init='random' , and get the best result for 10 times (n_init=10)
        #‘k-means++’ : selects initial cluster centers for k-mean clustering in a smart way to speed up convergence. 
        
        kmeans = KMeans(n_clusters=k,init='random',n_init=10).fit(X)  
       
        
        return kmeans.labels_
    
    

#--------------------------------------------------------------------------

#    covariance_type : {‘full’ (default), ‘tied’, ‘diag’, ‘spherical’}
#    String describing the type of covariance parameters to use. Must be one of:
#    
#    ‘full’
#    each component has its own general covariance matrix
#    
#    ‘tied’
#    all components share the same general covariance matrix
#    
#    ‘diag’
#    each component has its own diagonal covariance matrix
#    
#    ‘spherical’
#    each component has its own single variance



class GaussianMixtureModel:    
    
    def __init__(self,covariance_type='full'):
               
        self.covariance_type=covariance_type       
        
    def fit(self,X,k):
        
        nF=X.shape[1]
        
        if nF>2000:         # out of menory
            gmm = GaussianMixture(n_components=k, covariance_type='spherical').fit(X)
        else:
            gmm = GaussianMixture(n_components=k, covariance_type=self.covariance_type).fit(X)
            
        return gmm.predict(X)




   
    
    
#-----------------------------------------------------------------------------------
    
# affinity : string or callable, default: “euclidean”
# Metric used to compute the linkage. Can be “euclidean”, “l1”, “l2”, “manhattan”, “cosine”, or “precomputed”. If linkage is “ward”, only “euclidean” is accepted. If “precomputed”, a distance matrix (instead of a similarity matrix) is needed as input for the fit method.

# linkage : {“ward”, “complete”, “average”, “single”}, optional (default=”ward”)
# Which linkage criterion to use. The linkage criterion determines which distance to use between sets of observation. The algorithm will merge the pairs of cluster that minimize this criterion.

# ward minimizes the variance of the clusters being merged.
# average uses the average of the distances of each observation of the two sets.
# complete or maximum linkage uses the maximum distances between all observations of the two sets.
# single uses the minimum of the distances between all observations of the two sets.
        
class AgglomerativClusteringModel:    

    def __init__(self, affinity='euclidean', linkage='ward'):
        
        self.affinity=affinity
        self.linkage=linkage        
        
    def fit(self,X,k):
        
        return AgglomerativeClustering(n_clusters=k, affinity=self.affinity, linkage=self.linkage).fit_predict(X) 



#-------------------------------------------
    

# threshold : float, default 0.5
# The radius of the subcluster obtained by merging a new sample and the closest subcluster should be lesser than the threshold. Otherwise a new subcluster is started. Setting this value to be very low promotes splitting and vice-versa.
#
# branching_factor : int, default 50
# Maximum number of CF subclusters in each node. If a new samples enters such that the number of subclusters exceed the branching_factor then that node is split into two nodes with the subclusters redistributed in each. The parent subcluster of that node is removed and two new subclusters are added as parents of the 2 split nodes.

class BirchModel:    
    
    def __init__(self, branching_factor=50,threshold=0.5):
        
        self.branching_factor=branching_factor
        self.threshold=threshold        
        
    def fit(self,X,k):
        
        return Birch(branching_factor=self.branching_factor, n_clusters=k, threshold=self.threshold).fit_predict(X) 
    
    
    
    

#----------------clustering algorithm (type=2)----------------------
        
    
    

class MeanShiftModel:    
    
    def __init__(self, branching_factor=50,threshold=0.5):
        
        self.branching_factor=branching_factor
        self.threshold=threshold        
        
    def fit(self,X):
        
        clustering = MeanShift().fit(X)
        
        return clustering.labels_






#-------------------------------------------
    

class SpectraClusteringModel:    
    
    def __init__(self, affinity='rbf',gamma=1):
        
        self.affinity=affinity
        self.gamma=gamma        
        
    def fit(self,X,k):
        
        return SpectralClustering(n_clusters=k, affinity=self.affinity, gamma=self.gamma).fit_predict(X) 
        
        

#-------------------------------------------
    

class AffinityPropagationModel:    
    
    def __init__(self,affinity='euclidean', damping=0.5,  preference=None):
        
        self.affinity=affinity
        self.damping=damping
        self.preference=preference    
        
    def fit(self,X):
        
        model = AffinityPropagation(affinity=self.affinity, damping=self.damping, preference=self.preference)
        
        model.fit(X)
        
        return model.labels_        
        

#------------------------------------------------------------------
    






class NoisingByNeighbours:
    
    # def __init__(self):       
             
     

    def AddNoiseToX(self,X,ratio=2):
        
        
        noisedX=X.copy()
        
        nX=X.shape[0]          
        nF=X.shape[1]
        
        
        distA=pdist(X,metric='euclidean')
        # 将distA数组变成一个矩阵
        distX = squareform(distA)


        c=ratio/np.sqrt(nF)
        
        for i in range(nX):
            distX[i,i]=100000000
            
            minD= np.min(distX[i,:])
            
            noise=np.random.randn(nF)*minD*c
            
            noisedX[i,:]+=noise
        
        return noisedX



#---------------------------------------------------------------


class NoisingByCombingGaussianAndNeighbours:
    
    # def __init__(self):       
             
     

    def AddNoise0(self,X,ratio=0.1):
   
        nX=X.shape[0]
        nF=X.shape[1]
        
        noisedX=np.zeros((nX,nF))
        
        for i in range(X.shape[1]):
    #            _mean = np.mean(X[:,i])
            _var = np.var(X[:,i])
            _stdVar=np.sqrt(_var)
            
            #print(_mean,_var,_stdVar)
            
            
            noise=np.random.randn((nX))*_stdVar*ratio
            
            noisedX[:,i]=X[:,i]+noise
        
        return noisedX
    
        
    def AddNoiseToX(self,X,ratio1=0.05,ratio2=1):

        nX=X.shape[0]
        nF=X.shape[1]
        
        if nF>2000:         # out of menory
            noisedX= self.AddNoise0(X,ratio1) 
        else:        
         
            covX=np.cov(X.T)               
            noise=np.random.multivariate_normal(np.zeros(nF,),covX,nX)*ratio1                 
            noisedX=X+noise
        
        
        noising= NoisingByNeighbours()
       
        return noising.AddNoiseToX(noisedX,ratio2)
        
            
       
            




#---------------------------------------------------------------



class NoisingForCategory:
    
    # def __init__(self):       
             
     

    def grades_keys(self,X,i):
        
        cc = Counter(X[:,i])
        keys=list(cc)
        
        grades=np.zeros(len(keys)+1)
        
        grades[0]=0
        
        for k in range(len(keys)):
            
            grades[k+1]=grades[k]+cc[keys[k]]
            
        return [grades,keys]
      
    
    def RandV(self,grades,keys,value):
        
        for i in range(100):
            
            t=np.random.randint(0,grades[len(grades)-1])   
            
            for k in range(len(grades)):
                if t<grades[k]:
                    if (value!=keys[k-1]):
                        return keys[k-1]
                    break
            
        return value
            
    
    def Noising_Col_i(self,X,i,ratio):
        
        nX=X.shape[0]
    
        randX=np.random.rand(nX)
        
        idx=np.where(randX<ratio)        
        
        [grades,keys]=self.grades_keys(X,i)      
        
        for iRow in idx[0]:          
            X[iRow,i]=self.RandV(grades,keys,X[iRow,i])
         
        
     
           
            
    def AddNoiseToX(self,X,ratio=0.1):
        
        noisedX=X.copy()      
        
        for i in range(X.shape[1]):
            self.Noising_Col_i(noisedX,i,ratio)
      
        
        return noisedX
           



#------------------------------------------------------------------------------------------


# X=np.random.randn(3,5)

# covX=np.cov(X.T)       

# nX=X.shape[0]        
# nF=X.shape[1]

# noiseRatio=0.1
# noise=np.random.multivariate_normal(np.zeros(nF,),covX,nX)*noiseRatio    






class OPClustering:
    
    
    def __init__(self):       
       
        
        self.methods={}       
        
        self.methods2={}
        
        self.FigureOff=False
        
        
        self.ratio1=0.05
        self.ratio2=1
      
        
     # methodType==1 means that we can assign the K for the method, otherwise, the method can compute the K itself.
    
    def AddClusteringMethod(self,name,method,methodType=1):
        
        if methodType==1:
            self.methods[name]=method
        else:
            self.methods2[name]=method
        
        
    
                        

    #--------------------------------------------------------------------
        
        
        
        
    def PlotClusters(self,X,Y,bSubPlot=False):
        
        if self.FigureOff:
            return        
      
#        plt.rcParams['figure.figsize'] = (4.0, 4.0) # 设置figure_size尺寸    
        
        colors = ['r','g', 'b','c','m',  'y']  
        
        markers=['.','+','*','x','d']
        
        labels=pd.value_counts(Y)   
        
        for i in range(len(labels)):
            
            clusterID=int(labels.index[i])
                
            idx=np.where(Y==clusterID)
        
            plt.scatter(X[idx,0],X[idx,1],c=colors[clusterID%len(colors)],marker=markers[clusterID%len(markers)])
            
    #    plt.legend(loc=(1, 0))
            
        if bSubPlot==False:
             plt.show()    
      
        
        
            
        
        
    def AddNoise0(self,X,noiseRatio):
   
        nX=X.shape[0]
        nF=X.shape[1]
        
        noisedX=np.zeros((nX,nF))
        
        for i in range(X.shape[1]):
    #            _mean = np.mean(X[:,i])
            _var = np.var(X[:,i])
            _stdVar=np.sqrt(_var)
            
            #print(_mean,_var,_stdVar)
            
            
            noise=np.random.randn((nX))*_stdVar*noiseRatio
            
            noisedX[:,i]=X[:,i]+noise
        
        return noisedX
    
        
    def AddNoise(self,X,noiseRatio,covX=None):

        nX=X.shape[0]
        nF=X.shape[1]
        
        if (nF==1) or (nF>2000):         # out of menory
            return self.AddNoise0(X,noiseRatio) 

        if covX is None:
            covX=np.cov(X.T)       
        
        noise=np.random.multivariate_normal(np.zeros(nF,),covX,nX)*noiseRatio     
        
            
        return X+noise
            
            
   
    
            
    def GenerateXX(self, X,n,noiseRatio=0.1,nosingMethod='gaussian'):
        XX=[]
        XX.append(X)
        
        
        if nosingMethod=='gaussian':
            
            covX=None
            if (X.shape[1]<=2000) and (X.shape[1]>1):
                covX=np.cov(X.T)
            
            for i in range(n):
                XX.append(self.AddNoise(X,noiseRatio,covX))     
                
        if nosingMethod=='category':      
            
            noising= NoisingForCategory()
            
            for i in range(n):
                XX.append(noising.AddNoiseToX(X,noiseRatio))  
                
                
        if nosingMethod=='noisingByNeighbours':      
            
            noising= NoisingByNeighbours()
            
            for i in range(n):
                XX.append(noising.AddNoiseToX(X,noiseRatio))  
                
                
        if nosingMethod=='combingGaussianAndNeighbours':      
            
            noising= NoisingByCombingGaussianAndNeighbours()
            
            for i in range(n):
                XX.append(noising.AddNoiseToX(X,self.ratio1,self.ratio2))  
                
                
            
            
        return XX
        
        
       #----------------------------------------
       
       
       
    
   
    
        
    def ClusteringXX(self,XX,clusteringMethod,k=-1):
        
        results=[]
        
        for i in range(len(XX)):
            
            try:
                
                if k>0:
                    clusterid=clusteringMethod(XX[i],k)
                else:
                    clusterid=clusteringMethod(XX[i])
               
                results.append(clusterid)
                
            except Exception as e:
                
                print('**********************************************')
                print('Error in clustering method ', clusteringMethod)
                print('Reason',e)
                print('**********************************************')
                
                raise RuntimeError('error in clustering method ', clusteringMethod)
                
                return results
                
            
        return results   
    
    
    
    def RunMethod(self,XX,Y,minK,maxK,clusteringMethod,clusteringName):
        
        bSuccess=True
         
        infos=[]
          
         
        for k in range(minK,maxK):       
                
                info={}
                
                try:
                    results=self.ClusteringXX(XX,clusteringMethod,k)   
                except:                               
                    bSuccess=False 
                    break                
              
                
                kernelSets=self.Kernel(results,len(XX)-1)
                
                if kernelSets is None:     # some algorithms can not get clustering results on some data
                    bSuccess=False 
                    break
                
    #            kernelSets=Kernel2(results,XXCount-1)
                
    #            print(kernelSets)
                
                information=self.Information(kernelSets,XX[0].shape[0])
                
                info['method']=clusteringName
                
                info['k']=k
                info['results']=results
               
          
                info['kernelSets']=kernelSets            
                info['information']=information   
                
                infos.append(info)  
            
        return [infos,bSuccess]
    #           
                
    
    
    
    def SaveEvaluationResults0(self,Y,infos,sortedIdx,filename):
        
        content= 'method,k,information,NMI,ARI,FMI,homogeneity,completeness,v_measure,stabilityScore,realK\n'
        
        realK=len(set(Y))
             
        for k in range(len(infos)):
            
            info=infos[sortedIdx[k]]
            
            self.Evaluation(info,Y,False)
                               
            content+="{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}\n".format(info['method'],info['k'],info['information'],info['NMI'],info['ARI'],info['FMI'],info['homogeneity'],info['completeness'],info['v_measure'],info['stabilityScore'],realK)
     
        fd = os.open(filename,os.O_RDWR|os.O_CREAT)
        
        os.write(fd,str.encode(content))
        
        os.close(fd)
        
        
        
        
    def SaveEvaluationResults(self,Y,savePath,infos,sortedIdx,infos2,sortedIdx2):
        
        if savePath!='':
            
            print('-------------save reulsts----------------')
            
            if os.path.exists(savePath)==False:
                os.makedirs(savePath)
            
            for i in range(200):
                filename=savePath+"/result"+str(i)
                if os.path.isfile(filename+"_all.csv")==False:   
                    break
            
#            self.SaveEvaluationResults0(Y,infos,sortedIdx,filename+"_1.csv")            
#            self.SaveEvaluationResults0(Y,infos2,sortedIdx2,filename+"_2.csv")
            
            if (infos is None) and (infos2 is None):
                return
            
               
            if ( not( infos2 is None) ) and (infos is None):  
                infos=infos2
            elif ( not( infos2 is None) ) and (not (infos is None)):  
                infos.extend(infos2)
            
                              
            allScores=np.zeros(len(infos))
            
            for j in range(len(infos)):                      
                allScores[j]=infos[j]['information']
                
            sortedIdx_all=np.argsort(allScores) 
            
            self.SaveEvaluationResults0(Y,infos,sortedIdx_all,filename+"_all.csv")    
            
            
            
            
        
    
    def OpCluster(self,X,Y=None,minK=2,maxK=16,savePath='',noiseRatio=0.1, noisingMethod='gaussian'):   
        

                
        XXCount=10
        
        XX=self.GenerateXX(X,XXCount-1,noiseRatio,noisingMethod)       
        
        infos=infos2=None
        sortedIdx=sortedIdx2=None
               
        if len(self.methods)>0:
           [infos,sortedIdx]= self.OpCluster1(XX,Y,minK,maxK,savePath)          
            
        if len(self.methods2)>0:
            [infos2,sortedIdx2]=self.OpCluster2(XX,Y)
            
            
        if not( (Y is None) or (savePath=='') ) :
            self.SaveEvaluationResults(Y,savePath,infos,sortedIdx,infos2,sortedIdx2)
        
            
            
                
               
                
        
        
    
    
    def OpCluster1(self,XX,Y=None,minK=2,maxK=16,savePath=''):                   
        
        
        scores_for_each_method=[]
        list_of_successful_method=[]
        infos=[]
        
          
        for clusteringName,clusteringMethod in self.methods.items():           
          
            print(' ')
            print('-------------',clusteringName,' running----------------')
            
            infoList, bSuccess=self.RunMethod(XX,Y,minK,maxK,clusteringMethod,clusteringName)
            
           
            
            if bSuccess==False:
                continue
            
            scores=np.zeros(len(infoList))
            
            for j in range(len(infoList)):                      
                scores[j]=infoList[j]['information']
                
            
            scores_for_each_method.append(scores)
            list_of_successful_method.append(clusteringName)
            
            for info in infoList:
                infos.append(info)
        
       
        #----------------------------------------
        
        if not self.FigureOff:
        
            plt.cla()
            
            _fontsize=14
            plt.xticks(fontsize=_fontsize)
            plt.yticks(fontsize=_fontsize)     
            plt.legend(fontsize=_fontsize)
    
            colors = ['r','g', 'b','c', 'y']    
            
            linestyles=['--','-','-.']
                
            plt.rcParams['figure.figsize'] = (8.0, 4.0) # 设置figure_size尺寸
            
            plt.figure()
            
            plt.xticks(np.arange(0, maxK+1, 1)) 
            
            for i in range(len(list_of_successful_method)):
                plt.plot(range(minK,maxK),scores_for_each_method[i],label=list_of_successful_method[i],color=colors[i%len(colors)],linestyle=linestyles[i%len(linestyles)])   
                
            leg = plt.legend(loc = 'best',fontsize=_fontsize)
            leg.get_frame().set_alpha(0.2)
            
            plt.xlabel('k',fontsize=_fontsize)
            plt.ylabel('information',fontsize=_fontsize)
                       
            
            plt.rcParams['savefig.dpi'] = 100 #图片像素
            plt.rcParams['figure.dpi'] = 300 #分辨率
            
           
            if len(savePath)>0:
                if os.path.exists(savePath)==False:
                    os.makedirs(savePath)
                savePath+='/'    
                
            plt.savefig(savePath+'opClustering.jpg', dpi=300)
            
            plt.show()
        
        
        
        #-------------------------suggestions for the clustering algorithm----------------------
        
        
        allScores=np.ones(len(infos))

        
        for i in range(len(infos)):
            allScores[i]=infos[i]['information']
            
        
        sortedIdx=np.argsort(allScores) 
        
        topK=min(3,len(allScores))
        
        print('----------- suggestions for clustering algorithms and parameters  -------------')
        
   
        
        for k in range(topK):    
            
            info=infos[sortedIdx[k]]
            info['stabilityScore']=round(self.ClusteringMeasurement(info['results']),2)
            print(info['method']+' k='+str(info['k'])+' information='+str(int(info['information']))+' stability='+str((info['stabilityScore'])) )
            
            if not(Y is None):              
                
                self.Evaluation(info,Y)
        
        return [infos,sortedIdx]
                
                  
                              
            
        
        
                
                           
    def OpCluster2(self,XX,Y=None):    
               
        
       
        infos=[]
        scores=[]
          
        for clusteringName,clusteringMethod in self.methods2.items():           
          
            print(' ')
            print('-------------',clusteringName,' running----------------')
            
            
            info={}
                
            try:
                results=self.ClusteringXX(XX,clusteringMethod)    
                    
            except:      
                
                break
            
             
            
            kernelSets=self.Kernel(results,len(XX)-1)
            
            if kernelSets is None:
                continue
            
#            kernelSets=Kernel2(results,XXCount-1)
            
#            print(kernelSets)
            
            information=self.Information(kernelSets,XX[0].shape[0])
            
            info['method']=clusteringName
            
            
            cSet=self.ClusteridToSet(results[0])           
                
            info['k']=len(cSet)
            
            info['results']=results
      
            info['kernelSets']=kernelSets            
            info['information']=information     
            
            infos.append(info)  
                
            scores.append(information)           
                   
        
        #-------------------------show the results ----------------------       
                           
        
        sortedIdx=np.argsort(scores) 
        
        print('----------- suggestions for clustering algorithms (type=2) and parameters  -------------')
        
   
        topK=min(3,len(scores))
        
        for k in range(topK):    
            
            info=infos[sortedIdx[k]]
            
            info['stabilityScore']=round(self.ClusteringMeasurement(info['results']),2)
            
            print(info['method']+' k='+str(info['k'])+' information='+str(int(info['information']))+' stability='+str((info['stabilityScore'])) )
            
            if not(Y is None):              
                
                self.Evaluation(info,Y)
             
            
        return [infos,sortedIdx]
                
                
                
                
        
        
    def Evaluation(self,info,Y,showOption=True):
        
        results=info['results']                       
        
        if info['k']<2:
            info['NMI']=info['ARI']=info['AvgScore']=info['FMI']=info['homogeneity']=info['completeness']=info['v_measure']=info['stabilityScore']=0
            
        else:            
                
            info['NMI']=round(metrics.normalized_mutual_info_score(Y,results[0]),2)
            info['ARI']=round(metrics.adjusted_rand_score(Y,results[0]),2)                           
            info['FMI']=round(metrics.fowlkes_mallows_score(Y,results[0]),2)
            info['homogeneity']=round(metrics.homogeneity_score(Y,results[0]),2) 
            info['completeness']=round(metrics.completeness_score(Y,results[0]),2) 
            info['v_measure']=round(metrics.v_measure_score(Y,results[0]),2)    
#            info['stabilityScore']=round(self.ClusteringMeasurement(results),2)
              
        if showOption==True:            
            print('NMI=',info['NMI'],' ARI=',info['ARI'],' FMI=',info['FMI'])       
#            print('NMI=',info['NMI'],' ARI=',info['ARI'],' AvgScore=',info['AvgScore'])      
            print('homogeneity=',info['homogeneity'],' completeness=',info['completeness'],' v_measure=',info['v_measure'])                       
            print('stabilityScore=',info['stabilityScore'])
            print(' ')
                    
                
                        
            
          
       
    def MultipleClusteringWithNoise(self,X, k,noiseRatio=0.1, plot=True):    
        
        
        XX=self.GenerateXX(X,4,noiseRatio)               
        
        plt.rcParams['figure.figsize'] = (10.0, 2.0) # 设置figure_size尺寸
        
        for clusteringName,clusteringMethod in self.methods.items():           
              
            results=self.ClusteringXX(XX,clusteringMethod,k)    
            
            print(clusteringName+" "+"k="+str(k))   
    #        print(methods[i],k,score)   
            
            if plot==True:
                
                for n in range(5):
                    ax1 = plt.subplot(1,5,n+1) 
                    
                    if n==2:
                        plt.title(clusteringName+' k='+str(k))
                    ax1.set(aspect=1)
                    plt.sca(ax1)                
                    self.PlotClusters(XX[n],results[n],True)      
                    
               
    
                plt.savefig(clusteringName+'.jpg', dpi=300)
                plt.show()          
                
               
                
            
                
    
    
    
    #---------------------------------------------------------------
    
    
    def ClusteringMeasurement(self,results,option=1):     
        
        totalScore=0
        count=0              
            
        if option==0:
            
            for i in range(len(results)):
                for j in range(i+1,len(results)):
                     score = metrics.normalized_mutual_info_score(results[i],results[j])   
                     
                     if score>1.001:
                         print('error: score=', score,i,j)
                         
                         print(pd.value_counts(results[i]))
                         
                         print(pd.value_counts(results[j]))
                         
                         score=0
                         
                     
                     totalScore=totalScore+score    
                     count=count+1     
        else:
           
            for j in range(1,len(results)):  
                
                 score = metrics.normalized_mutual_info_score(results[0],results[j])   
                 
                 if score>1.001:
                         print('error: score=', score,i,j)
                         
                         print(pd.value_counts(results[i]))
                         
                         print(pd.value_counts(results[j]))
                         
                         score=0
                 
                 totalScore=totalScore+score    
                 count=count+1   
        
        return totalScore/count
        
       
       
    
    
    
    def ClusteringMeasurementByRealY(self,results,Y):     
        
        totalScore=0
        count=0
       
        for j in range(len(results)):
             score = metrics.normalized_mutual_info_score(Y,results[j])             
             totalScore=totalScore+score    
             count=count+1   
             
        
        return totalScore/count
        
    
    
    
    
    def ClusteridToSet(self,clusterid):
        
        clusterSet=[]
        
        labels=pd.value_counts(clusterid)   
        
        for i in range(len(labels)):
            
            clusterID=labels.index[i]
            
            if clusterID==-1:
                continue
            
            idx=np.where(clusterid==clusterID)
            
            clusterSet.append(set(idx[0]))
            
        return clusterSet
            
            
            
         
    def MaxIntersection(self,rscSet,dstSets,flag):
        
        maxIntersection=0
        
        maxIdx=0
        
        for i in range(len(dstSets)):
            if flag[i]==0:     
                    
                intersectionSet=rscSet&dstSets[i]
                
                if len(intersectionSet)>=maxIntersection:
                    maxIntersection=len(intersectionSet)
                    maxIdx=i
                    
        return [maxIdx,rscSet&dstSets[maxIdx]]
                    
                
    
        
    def Kernel(self,results,count):
     
          
        cSet0=self.ClusteridToSet(results[0])      
        
        ck=len(cSet0)
        
        sets=[]
        
        for i in range(1,len(results)):
            
            cSet=self.ClusteridToSet(results[i])
            
            for j in range(len(cSet)):
                sets.append(cSet[j])   
            
            #-------------for the algorithms such as meanshift, AP,-----
            if ck!=len(cSet) and( (ck<5) or (len(cSet)<5) ):
                return None                   
            #----------------------        
        
        kernelSets=[]
        
        
        
        for k in range(len(cSet0)):        
        
            rscSet=cSet0[k]             
            
            flag=np.zeros(len(sets))
            
            for i in range(count-1):
                maxIdx,rscSet=self.MaxIntersection(rscSet,sets,flag)
                flag[maxIdx]=1

            
            if(len(rscSet)>1):  # for AP clustering, its clusters always contain only one point
                kernelSets.append(rscSet)    
            
            
        return kernelSets
            
            
    
    
    
    
    def Information(self,kernelSets,totalCount):
        
        info=0
        
        numberInCluster=0
        
        for i in range(len(kernelSets)):
            count=len(kernelSets[i])
            numberInCluster+=count
           
        numberNotInCluster=totalCount-numberInCluster
        
        if numberNotInCluster>0:
            info+=-numberNotInCluster*np.log2(1/totalCount)      
        

        
        for i in range(len(kernelSets)):
            count=len(kernelSets[i])       
            info+=-count*np.log2(1/(count+numberNotInCluster))
            
            

            
        return info
        
        
    
    
    
    
    
    









